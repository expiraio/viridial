<template>
  <div
    class="antialiased flex h-full text-base text-foreground bg-background demo1 kt-sidebar-fixed kt-header-fixed"
  >
    <div class="flex grow">
      <!-- Sidebar -->
      <div
        class="kt-sidebar bg-background border-e border-e-border fixed z-20 hidden lg:flex flex-col items-stretch shrink-0 [--kt-drawer-enable:true] lg:[--kt-drawer-enable:false]"
      >
        <div
          class="kt-sidebar-header hidden lg:flex items-center relative justify-between px-3 lg:px-6 shrink-0"
          id="sidebar_header"
        >
          <a class="dark:hidden" href="/metronic/tailwind/demo1/">
            <img
              class="default-logo min-h-[22px] max-w-none"
              src="../assets/img/default-logo.svg"
            />
            <img
              class="small-logo min-h-[22px] max-w-none"
              src="../assets/img/mini-logo.svg"
            />
          </a>
          <a class="hidden dark:block" href="/metronic/tailwind/demo1/">
            <img
              class="default-logo min-h-[22px] max-w-none"
              src="../assets/img/default-logo-dark.svg"
            />
            <img
              class="small-logo min-h-[22px] max-w-none"
              src="../assets/img/mini-logo.svg"
            />
          </a>
          <button
            class="kt-btn kt-btn-outline kt-btn-icon size-[30px] absolute start-full top-2/4 -translate-x-2/4 -translate-y-2/4 rtl:translate-x-2/4"
            data-kt-toggle="body"
            data-kt-toggle-class="kt-sidebar-collapse"
            id="sidebar_toggle"
            data-kt-toggle-initialized="true"
          >
            <ArrowLeftFromLine
              class="ki-filled ki-black-left-line kt-toggle-active:rotate-180 transition-all duration-300 rtl:translate rtl:rotate-180 rtl:kt-toggle-active:rotate-0"
            />
          </button>
        </div>
        <div class="kt-sidebar-content flex grow shrink-0 py-5 pe-2">
          <div
            class="kt-scrollable-y-hover grow shrink-0 flex ps-2 lg:ps-5 pe-1 lg:pe-3"
            style="height: 428px"
          >
            <div class="kt-menu flex flex-col grow gap-1">
              <div class="kt-menu-item here show kt-menu-item-accordion">
                <div
                  class="kt-menu-link flex items-center grow cursor-pointer border border-transparent gap-[10px] ps-[10px] pe-[10px] py-[6px]"
                >
                  <span
                    class="kt-menu-icon items-start text-muted-foreground w-[20px]"
                  >
                    <i class="ki-filled ki-element-11 text-lg"> </i>
                  </span>
                  <span
                    class="kt-menu-title text-sm font-medium text-foreground kt-menu-item-active:text-primary kt-menu-link-hover:!text-primary"
                  >
                    Dashboards
                  </span>
                  <span
                    class="kt-menu-arrow text-muted-foreground w-[20px] shrink-0 justify-end ms-1 me-[-10px]"
                  >
                    <span class="inline-flex kt-menu-item-show:hidden">
                      <i class="ki-filled ki-plus text-[11px]"> </i>
                    </span>
                    <span class="hidden kt-menu-item-show:inline-flex">
                      <i class="ki-filled ki-minus text-[11px]"> </i>
                    </span>
                  </span>
                </div>
                <div
                  class="kt-menu-accordion gap-1 ps-[10px] relative before:absolute before:start-[20px] before:top-0 before:bottom-0 before:border-s before:border-border"
                >
                  <div class="kt-menu-item active">
                    <a
                      class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                      href="/metronic/tailwind/demo1/"
                      tabindex="0"
                    >
                      <span
                        class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                      >
                      </span>
                      <span
                        class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                      >
                        Light Sidebar
                      </span>
                    </a>
                  </div>
                  <div class="kt-menu-item">
                    <a
                      class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                      href="/metronic/tailwind/demo1/dashboards/dark-sidebar"
                      tabindex="0"
                    >
                      <span
                        class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                      >
                      </span>
                      <span
                        class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                      >
                        Dark Sidebar
                      </span>
                    </a>
                  </div>
                </div>
              </div>
              <div class="kt-menu-item pt-2.25 pb-px">
                <span
                  class="kt-menu-heading uppercase text-xs font-medium text-muted-foreground ps-[10px] pe-[10px]"
                >
                  User
                </span>
              </div>
              <div
                class="kt-menu-item kt-menu-item-accordion"
                data-kt-menu-item-toggle="accordion"
                data-kt-menu-item-trigger="click"
              >
                <div
                  class="kt-menu-link flex items-center grow cursor-pointer border border-transparent gap-[10px] ps-[10px] pe-[10px] py-[6px]"
                  tabindex="0"
                >
                  <span
                    class="kt-menu-icon items-start text-muted-foreground w-[20px]"
                  >
                    <i class="ki-filled ki-profile-circle text-lg"> </i>
                  </span>
                  <span
                    class="kt-menu-title text-sm font-medium text-foreground kt-menu-item-active:text-primary kt-menu-link-hover:!text-primary"
                  >
                    Public Profile
                  </span>
                  <span
                    class="kt-menu-arrow text-muted-foreground w-[20px] shrink-0 justify-end ms-1 me-[-10px]"
                  >
                    <span class="inline-flex kt-menu-item-show:hidden">
                      <i class="ki-filled ki-plus text-[11px]"> </i>
                    </span>
                    <span class="hidden kt-menu-item-show:inline-flex">
                      <i class="ki-filled ki-minus text-[11px]"> </i>
                    </span>
                  </span>
                </div>
                <div
                  class="kt-menu-accordion gap-1 ps-[10px] relative before:absolute before:start-[20px] before:top-0 before:bottom-0 before:border-s before:border-border"
                  style="height: 0px"
                >
                  <div
                    class="kt-menu-item kt-menu-item-accordion"
                    data-kt-menu-item-toggle="accordion"
                    data-kt-menu-item-trigger="click"
                  >
                    <div
                      class="kt-menu-link border border-transparent grow cursor-pointer gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                      tabindex="0"
                    >
                      <span
                        class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                      >
                      </span>
                      <span
                        class="kt-menu-title text-2sm font-normal me-1 text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-medium kt-menu-link-hover:!text-primary"
                      >
                        Profiles
                      </span>
                      <span
                        class="kt-menu-arrow text-muted-foreground w-[20px] shrink-0 justify-end ms-1 me-[-10px]"
                      >
                        <span class="inline-flex kt-menu-item-show:hidden">
                          <i class="ki-filled ki-plus text-[11px]"> </i>
                        </span>
                        <span class="hidden kt-menu-item-show:inline-flex">
                          <i class="ki-filled ki-minus text-[11px]"> </i>
                        </span>
                      </span>
                    </div>
                    <div
                      class="kt-menu-accordion gap-1 relative before:absolute before:start-[32px] ps-[22px] before:top-0 before:bottom-0 before:border-s before:border-border"
                    >
                      <div class="kt-menu-item">
                        <a
                          class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                          href="/metronic/tailwind/demo1/public-profile/profiles/default"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                          >
                            Default
                          </span>
                        </a>
                      </div>
                      <div class="kt-menu-item">
                        <a
                          class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                          href="/metronic/tailwind/demo1/public-profile/profiles/creator"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                          >
                            Creator
                          </span>
                        </a>
                      </div>
                      <div class="kt-menu-item">
                        <a
                          class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                          href="/metronic/tailwind/demo1/public-profile/profiles/company"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                          >
                            Company
                          </span>
                        </a>
                      </div>
                      <div class="kt-menu-item">
                        <a
                          class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                          href="/metronic/tailwind/demo1/public-profile/profiles/nft"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                          >
                            NFT
                          </span>
                        </a>
                      </div>
                      <div class="kt-menu-item">
                        <a
                          class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                          href="/metronic/tailwind/demo1/public-profile/profiles/blogger"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                          >
                            Blogger
                          </span>
                        </a>
                      </div>
                      <div class="kt-menu-item">
                        <a
                          class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                          href="/metronic/tailwind/demo1/public-profile/profiles/crm"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                          >
                            CRM
                          </span>
                        </a>
                      </div>
                      <div
                        class="kt-menu-item flex-col-reverse kt-menu-item-accordion"
                        data-kt-menu-item-toggle="accordion"
                        data-kt-menu-item-trigger="click"
                      >
                        <div
                          class="kt-menu-link border border-transparent grow cursor-pointer gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-secondary-foreground"
                          >
                            <span class="hidden kt-menu-item-show:!flex">
                              Show less
                            </span>
                            <span class="flex kt-menu-item-show:hidden">
                              Show 4 more
                            </span>
                          </span>
                          <span
                            class="kt-menu-arrow text-muted-foreground w-[20px] shrink-0 justify-end ms-1 me-[-10px]"
                          >
                            <span class="inline-flex kt-menu-item-show:hidden">
                              <i class="ki-filled ki-plus text-[11px]"> </i>
                            </span>
                            <span class="hidden kt-menu-item-show:inline-flex">
                              <i class="ki-filled ki-minus text-[11px]"> </i>
                            </span>
                          </span>
                        </div>
                        <div class="kt-menu-accordion gap-1">
                          <div class="kt-menu-item">
                            <a
                              class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                              href="/metronic/tailwind/demo1/public-profile/profiles/gamer"
                              tabindex="0"
                            >
                              <span
                                class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                              >
                              </span>
                              <span
                                class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                              >
                                Gamer
                              </span>
                            </a>
                          </div>
                          <div class="kt-menu-item">
                            <a
                              class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                              href="/metronic/tailwind/demo1/public-profile/profiles/feeds"
                              tabindex="0"
                            >
                              <span
                                class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                              >
                              </span>
                              <span
                                class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                              >
                                Feeds
                              </span>
                            </a>
                          </div>
                          <div class="kt-menu-item">
                            <a
                              class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                              href="/metronic/tailwind/demo1/public-profile/profiles/plain"
                              tabindex="0"
                            >
                              <span
                                class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                              >
                              </span>
                              <span
                                class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                              >
                                Plain
                              </span>
                            </a>
                          </div>
                          <div class="kt-menu-item">
                            <a
                              class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                              href="/metronic/tailwind/demo1/public-profile/profiles/modal"
                              tabindex="0"
                            >
                              <span
                                class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                              >
                              </span>
                              <span
                                class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                              >
                                Modal
                              </span>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div
                    class="kt-menu-item kt-menu-item-accordion"
                    data-kt-menu-item-toggle="accordion"
                    data-kt-menu-item-trigger="click"
                  >
                    <div
                      class="kt-menu-link border border-transparent grow cursor-pointer gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                      tabindex="0"
                    >
                      <span
                        class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                      >
                      </span>
                      <span
                        class="kt-menu-title text-2sm font-normal me-1 text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-medium kt-menu-link-hover:!text-primary"
                      >
                        Projects
                      </span>
                      <span
                        class="kt-menu-arrow text-muted-foreground w-[20px] shrink-0 justify-end ms-1 me-[-10px]"
                      >
                        <span class="inline-flex kt-menu-item-show:hidden">
                          <i class="ki-filled ki-plus text-[11px]"> </i>
                        </span>
                        <span class="hidden kt-menu-item-show:inline-flex">
                          <i class="ki-filled ki-minus text-[11px]"> </i>
                        </span>
                      </span>
                    </div>
                    <div
                      class="kt-menu-accordion gap-1 relative before:absolute before:start-[32px] ps-[22px] before:top-0 before:bottom-0 before:border-s before:border-border"
                    >
                      <div class="kt-menu-item">
                        <a
                          class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                          href="/metronic/tailwind/demo1/public-profile/projects/3-columns"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                          >
                            3 Columns
                          </span>
                        </a>
                      </div>
                      <div class="kt-menu-item">
                        <a
                          class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[5px] ps-[10px] pe-[10px] py-[8px]"
                          href="/metronic/tailwind/demo1/public-profile/projects/2-columns"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                          >
                            2 Columns
                          </span>
                        </a>
                      </div>
                    </div>
                  </div>
                  <div class="kt-menu-item">
                    <a
                      class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                      href="/metronic/tailwind/demo1/public-profile/works"
                      tabindex="0"
                    >
                      <span
                        class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                      >
                      </span>
                      <span
                        class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                      >
                        Works
                      </span>
                    </a>
                  </div>
                  <div class="kt-menu-item">
                    <a
                      class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                      href="/metronic/tailwind/demo1/public-profile/teams"
                      tabindex="0"
                    >
                      <span
                        class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                      >
                      </span>
                      <span
                        class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                      >
                        Teams
                      </span>
                    </a>
                  </div>
                  <div class="kt-menu-item">
                    <a
                      class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                      href="/metronic/tailwind/demo1/public-profile/network"
                      tabindex="0"
                    >
                      <span
                        class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                      >
                      </span>
                      <span
                        class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                      >
                        Network
                      </span>
                    </a>
                  </div>
                  <div class="kt-menu-item">
                    <a
                      class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                      href="/metronic/tailwind/demo1/public-profile/activity"
                      tabindex="0"
                    >
                      <span
                        class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                      >
                      </span>
                      <span
                        class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                      >
                        Activity
                      </span>
                    </a>
                  </div>
                  <div
                    class="kt-menu-item flex-col-reverse kt-menu-item-accordion"
                    data-kt-menu-item-toggle="accordion"
                    data-kt-menu-item-trigger="click"
                  >
                    <div
                      class="kt-menu-link border border-transparent grow cursor-pointer gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                      tabindex="0"
                    >
                      <span
                        class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                      >
                      </span>
                      <span
                        class="kt-menu-title text-2sm font-normal text-secondary-foreground"
                      >
                        <span class="hidden kt-menu-item-show:!flex">
                          Show less
                        </span>
                        <span class="flex kt-menu-item-show:hidden">
                          Show 3 more
                        </span>
                      </span>
                      <span
                        class="kt-menu-arrow text-muted-foreground w-[20px] shrink-0 justify-end ms-1 me-[-10px]"
                      >
                        <span class="inline-flex kt-menu-item-show:hidden">
                          <i class="ki-filled ki-plus text-[11px]"> </i>
                        </span>
                        <span class="hidden kt-menu-item-show:inline-flex">
                          <i class="ki-filled ki-minus text-[11px]"> </i>
                        </span>
                      </span>
                    </div>
                    <div class="kt-menu-accordion gap-1">
                      <div class="kt-menu-item">
                        <a
                          class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                          href="/metronic/tailwind/demo1/public-profile/campaigns/card"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                          >
                            Campaigns - Card
                          </span>
                        </a>
                      </div>
                      <div class="kt-menu-item">
                        <a
                          class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                          href="/metronic/tailwind/demo1/public-profile/campaigns/list"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                          >
                            Campaigns - List
                          </span>
                        </a>
                      </div>
                      <div class="kt-menu-item">
                        <a
                          class="kt-menu-link border border-transparent items-center grow kt-menu-item-active:bg-accent/60 dark:menu-item-active:border-border kt-menu-item-active:rounded-lg hover:bg-accent/60 hover:rounded-lg gap-[14px] ps-[10px] pe-[10px] py-[8px]"
                          href="/metronic/tailwind/demo1/public-profile/empty"
                          tabindex="0"
                        >
                          <span
                            class="kt-menu-bullet flex w-[6px] -start-[3px] rtl:start-0 relative before:absolute before:top-0 before:size-[6px] before:rounded-full rtl:before:translate-x-1/2 before:-translate-y-1/2 kt-menu-item-active:before:bg-primary kt-menu-item-hover:before:bg-primary"
                          >
                          </span>
                          <span
                            class="kt-menu-title text-2sm font-normal text-foreground kt-menu-item-active:text-primary kt-menu-item-active:font-semibold kt-menu-link-hover:!text-primary"
                          >
                            Empty
                          </span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Main Content -->
      <div class="kt-wrapper flex grow flex-col">
        <!-- Top Header - Fixed (always visible) -->
        <header
          class="kt-header fixed top-0 z-10 start-0 end-0 flex items-stretch shrink-0 bg-background border-b border-border"
        >
          <div
            class="kt-container-fixed flex justify-between items-stretch lg:gap-4"
            id="headerContainer"
          >
            <div class="flex items-stretch">
              <div
                class="flex items-stretch [--kt-reparent-mode:prepend] [--kt-reparent-target:body] lg:[--kt-reparent-target:#megaMenuContainer] lg:[--kt-reparent-mode:prepend]"
              >
                <div
                  class="lg:flex lg:items-stretch [--kt-drawer-enable:true] lg:[--kt-drawer-enable:false] hidden"
                >
                  <div class="kt-menu flex-col lg:flex-row gap-5 lg:gap-7.5">
                    <div class="kt-menu-item active">
                      <a
                        class="kt-menu-link text-nowrap text-sm text-foreground font-medium kt-menu-item-hover:text-primary kt-menu-item-active:text-mono kt-menu-item-active:font-medium"
                        href="/metronic/tailwind/demo1/"
                      >
                        <span class="kt-menu-title text-nowrap"> Homes </span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="flex items-center gap-2.5">
              <Button
                class="group kt-btn kt-btn-ghost kt-btn-icon size-9 rounded-full hover:bg-primary/10 hover:[&_i]:text-primary"
              >
                <Search
                  class="ki-filled ki-magnifier text-lg group-hover:text-primary"
                />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger as-child>
                  <Button variant="outline">
                    <Avatar class="cursor-pointer shrink-0">
                      <AvatarImage
                        class="size-9 rounded-full border-2 border-green-500 shrink-0"
                        src="https://github.com/shadcn.png"
                        alt="@shadcn"
                      />
                      <AvatarFallback>CN</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent class="w-56" align="start">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuGroup>
                    <DropdownMenuItem>
                      Profile <DropdownMenuShortcut>⇧⌘P</DropdownMenuShortcut>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      Billing <DropdownMenuShortcut>⌘B</DropdownMenuShortcut>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      Settings <DropdownMenuShortcut>⌘S</DropdownMenuShortcut>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      Keyboard shortcuts
                      <DropdownMenuShortcut>⌘K</DropdownMenuShortcut>
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  <DropdownMenuGroup>
                    <DropdownMenuItem>Team</DropdownMenuItem>
                    <DropdownMenuSub>
                      <DropdownMenuSubTrigger
                        >Invite users</DropdownMenuSubTrigger
                      >
                      <DropdownMenuPortal>
                        <DropdownMenuSubContent>
                          <DropdownMenuItem>Email</DropdownMenuItem>
                          <DropdownMenuItem>Message</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>More...</DropdownMenuItem>
                        </DropdownMenuSubContent>
                      </DropdownMenuPortal>
                    </DropdownMenuSub>
                    <DropdownMenuItem>
                      New Team <DropdownMenuShortcut>⌘+T</DropdownMenuShortcut>
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>GitHub</DropdownMenuItem>
                  <DropdownMenuItem>Support</DropdownMenuItem>
                  <DropdownMenuItem disabled> API </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    Log out <DropdownMenuShortcut>⇧⌘Q</DropdownMenuShortcut>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>
        <main class="grow pt-5" role="content">
          <div class="kt-container-fixed" id="contentContainer"></div>
          <div class="kt-container-fixed">
            <div
              class="flex flex-wrap items-center lg:items-end justify-between gap-5 pb-7.5"
            >
              <div class="flex flex-col justify-center gap-2">
                <h1 class="text-xl font-medium leading-none text-mono">
                  Dashboard
                </h1>
                <div
                  class="flex items-center gap-2 text-sm font-normal text-secondary-foreground"
                >
                  Central Hub for Personal Customization
                </div>
              </div>
              <div class="flex items-center gap-2.5">
                <a
                  class="kt-btn kt-btn-outline"
                  href="/metronic/tailwind/demo1/public-profile/profiles/default"
                >
                  View Profile
                </a>
              </div>
            </div>
          </div>
          <div class="kt-container-fixed"><router-view /></div>
        </main>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { ref } from "vue";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Button from "@/components/ui/button/Button.vue";
import {
  LayoutDashboard,
  Users,
  Building2,
  Home,
  BarChart3,
  Settings,
  Bell,
  Menu,
  LogOut,
  Shield,
  AlertTriangle,
  FileText,
  CreditCard,
  Package,
  UserCog,
  List,
  Settings as SettingsIcon,
  Globe,
  Check,
  Search,
  ArrowLeftFromLine,
} from "lucide-vue-next";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuPortal,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
const showStatusBar = ref(true);
const showActivityBar = ref(false);
const showPanel = ref(false);
const position = ref("bottom");
</script>
