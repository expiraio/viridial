<script setup lang="ts">
import { TooltipTrigger as TooltipTriggerPrimitive, useForwardPropsEmits } from "reka-ui"

const props = defineProps()
const emits = defineEmits()

const forwarded = useForwardPropsEmits(props, emits)
</script>

<template>
  <TooltipTriggerPrimitive v-bind="forwarded">
    <slot />
  </TooltipTriggerPrimitive>
</template>

