<script setup lang="ts">
import type { HTMLAttributes } from "vue"
import { Primitive, type PrimitiveProps } from "reka-ui"
import { cn } from "@/lib/utils"

interface Props extends PrimitiveProps {
  orientation?: "horizontal" | "vertical"
  decorative?: boolean
  class?: HTMLAttributes["class"]
}

const props = withDefaults(defineProps<Props>(), {
  as: "div",
  orientation: "horizontal",
  decorative: true,
})
</script>

<template>
  <Primitive
    :as="as"
    :as-child="asChild"
    role="separator"
    :aria-orientation="orientation"
    :aria-hidden="decorative"
    :class="
      cn(
        'shrink-0 bg-border',
        orientation === 'horizontal' ? 'h-[1px] w-full' : 'h-full w-[1px]',
        props.class
      )
    "
  />
</template>

