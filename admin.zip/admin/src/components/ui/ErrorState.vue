<template>
  <div class="flex flex-col items-center justify-center py-16 space-y-4 px-4">
    <AlertTriangle class="w-12 h-12 text-destructive" />
    <div class="text-center space-y-2">
      <p class="font-medium text-foreground">{{ title || $t('errors.generic', 'Erreur') }}</p>
      <p class="text-sm text-muted-foreground">{{ message }}</p>
    </div>
    <Button v-if="showRetry !== false" variant="outline" @click="$emit('retry')">
      <RefreshCw class="w-4 h-4 mr-2" />
      {{ retryLabel || $t('common.retry', 'Réessayer') }}
    </Button>
  </div>
</template>

<script setup lang="ts">
import { Button } from '@/components/ui/button'
import { AlertTriangle, RefreshCw } from 'lucide-vue-next'
import { useI18n } from 'vue-i18n'

const { t: $t } = useI18n()

defineProps<{
  title?: string
  message: string
  showRetry?: boolean
  retryLabel?: string
}>()

defineEmits<{
  retry: []
}>()
</script>

