<template>
  <div class="flex flex-col items-center justify-center py-16 px-4 space-y-4">
    <div class="w-20 h-20 rounded-full bg-muted flex items-center justify-center">
      <component :is="icon" class="w-10 h-10 text-muted-foreground/50" />
    </div>
    <div class="text-center space-y-2 max-w-md">
      <p class="font-medium text-foreground">
        {{ title }}
      </p>
      <p v-if="description" class="text-sm text-muted-foreground">
        {{ description }}
      </p>
    </div>
    <div v-if="actionLabel" class="flex items-center gap-2">
      <Button v-if="actionVariant === 'outline'" variant="outline" @click="$emit('action')">
        <component v-if="actionIcon" :is="actionIcon" class="w-4 h-4 mr-2" />
        {{ actionLabel }}
      </Button>
      <Button v-else @click="$emit('action')">
        <component v-if="actionIcon" :is="actionIcon" class="w-4 h-4 mr-2" />
        {{ actionLabel }}
      </Button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Button } from '@/components/ui/button'
import type { Component } from 'vue'

defineProps<{
  icon: Component
  title: string
  description?: string
  actionLabel?: string
  actionIcon?: Component
  actionVariant?: 'default' | 'outline'
}>()

defineEmits<{
  action: []
}>()
</script>

