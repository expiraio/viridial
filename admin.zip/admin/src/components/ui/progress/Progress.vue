<script setup lang="ts">
import type { HTMLAttributes } from "vue"
import { computed } from "vue"
import { ProgressRoot, ProgressIndicator } from "reka-ui"
import { cn } from "@/lib/utils"

const props = defineProps<{
  modelValue?: number
  max?: number
  class?: HTMLAttributes["class"]
}>()

const percentage = computed(() => {
  if (!props.modelValue || !props.max) return 0
  return Math.min(100, Math.max(0, (props.modelValue / props.max) * 100))
})
</script>

<template>
  <ProgressRoot
    :model-value="percentage"
    :max="100"
    :class="cn('relative h-2 w-full overflow-hidden rounded-full bg-primary/20', props.class)"
  >
    <ProgressIndicator
      :class="cn('h-full w-full flex-1 bg-primary transition-all', props.class)"
      :style="{ transform: `translateX(-${100 - percentage}%)` }"
    />
  </ProgressRoot>
</template>

