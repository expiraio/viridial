<template>
  <Popover :open="open" @update:open="open = $event">
    <PopoverTrigger as-child>
      <Button
        variant="outline"
        role="combobox"
        :class="cn('w-full justify-between', !selectedValue && 'text-muted-foreground', props.class)"
        :disabled="disabled"
      >
        {{ selectedLabel || placeholder }}
        <ChevronsUpDown class="ml-2 h-4 w-4 shrink-0 opacity-50" />
      </Button>
    </PopoverTrigger>
    <PopoverContent class="w-[var(--radix-popover-trigger-width)] p-0" :align="'start'">
      <Command>
        <CommandInput :placeholder="searchPlaceholder" />
        <CommandEmpty>{{ emptyText }}</CommandEmpty>
        <CommandList>
          <CommandGroup>
            <CommandItem
              v-for="option in options"
              :key="String(option.value)"
              :value="String(option.value)"
              @select="handleSelect(option)"
            >
              <Check
                :class="cn('mr-2 h-4 w-4', selectedValue === String(option.value) ? 'opacity-100' : 'opacity-0')"
              />
              {{ option.label }}
            </CommandItem>
          </CommandGroup>
        </CommandList>
      </Command>
    </PopoverContent>
  </Popover>
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { Check, ChevronsUpDown } from 'lucide-vue-next'
import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command'
import { cn } from '@/lib/utils'

interface Option {
  value: string | number
  label: string
}

const props = withDefaults(defineProps<{
  modelValue?: string | number | null
  options: Option[]
  placeholder?: string
  searchPlaceholder?: string
  emptyText?: string
  class?: string
  disabled?: boolean
}>(), {
  placeholder: 'Select...',
  searchPlaceholder: 'Search...',
  emptyText: 'No results found.',
  disabled: false
})

const emit = defineEmits<{
  (e: 'update:modelValue', value: string | number | null): void
}>()

const open = ref(false)
const selectedValue = computed(() => props.modelValue ?? null)

const selectedLabel = computed(() => {
  if (!selectedValue.value) return null
  const option = props.options.find(opt => String(opt.value) === String(selectedValue.value))
  return option?.label || null
})

const handleSelect = (option: Option) => {
  emit('update:modelValue', option.value === '' ? null : option.value)
  open.value = false
}
</script>

