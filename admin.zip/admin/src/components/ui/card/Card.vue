<script setup lang="ts">
import type { HTMLAttributes } from "vue"
import { cn } from "@/lib/utils"

const props = defineProps<{
  class?: HTMLAttributes["class"]
}>()
</script>

<template>
  <div
    :class="
      cn(
        'mb-6 bg-white dark:bg-card transition-all duration-500 ease-in-out relative rounded-[5px] border border-[#E5E7EB] dark:border-border shadow-[0px_1px_1px_1px_rgba(198,198,198,0.2)] dark:shadow-lg text-inherit',
        props.class,
      )
    "
  >
    <slot />
  </div>
</template>
