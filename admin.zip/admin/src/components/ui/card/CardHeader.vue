<script setup lang="ts">
import type { HTMLAttributes } from "vue"
import { cn } from "@/lib/utils"

const props = defineProps<{
  class?: HTMLAttributes["class"]
}>()
</script>

<template>
  <div 
    :class="
      cn(
        'relative bg-transparent border-b border-[#E5E7EB] dark:border-border mb-0 py-3 px-5 first:rounded-t-[5px]',
        props.class
      )
    "
  >
    <slot />
  </div>
</template>
