<script setup lang="ts">
import { computed } from 'vue'
import type { CollapsibleRootEmits, CollapsibleRootProps } from "reka-ui"
import { CollapsibleRoot, useForwardPropsEmits } from "reka-ui"

const props = defineProps<CollapsibleRootProps & { open?: boolean }>()
const emits = defineEmits<CollapsibleRootEmits & { 'update:open': [value: boolean] }>()

const openValue = computed({
  get: () => props.open ?? false,
  set: (value) => emits('update:open', value)
})

const delegatedProps = computed(() => {
  const { open, ...rest } = props
  return rest
})

const forwarded = useForwardPropsEmits(delegatedProps.value, emits)
</script>

<template>
  <CollapsibleRoot v-slot="{ open: slotOpen }" v-bind="forwarded" :open="openValue" @update:open="openValue = $event">
    <slot :open="slotOpen ?? openValue" />
  </CollapsibleRoot>
</template>
