// src/router/index.ts
import { createRouter, createWebHistory } from "vue-router";
import DashboardLayout from "@/layouts/DefaultLayout.vue";
import DashboardHome from "@/views/Index.vue";
const routes = [
  // Root path - will be handled by navigation guard
  {
    path: "/",
    component: DashboardLayout,
    children: [
      {
        path: "",
        name: "Dashboard",
        component: DashboardHome,
        meta: { requiresAuth: true },
      },
    ],
  },
];

export const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
});
