# Classes Tailwind CSS - Style Steex Material Dashboard

Ce document liste toutes les classes Tailwind personnalisées converties depuis le CSS du thème Steex React Material Dashboard.

## 📦 Installation

Les classes sont déjà intégrées dans `src/assets/tailwind.css` et sont disponibles globalement dans votre application.

## 🎨 Classes disponibles

### Material Design Elevation (Ombres)

```html
<!-- Niveaux d'élévation Material Design -->
<div class="steex-elevation-0">Aucune ombre</div>
<div class="steex-elevation-1">Ombres légères</div>
<div class="steex-elevation-2">Ombres moyennes</div>
<div class="steex-elevation-3">Ombres fortes</div>
<div class="steex-elevation-4">Ombres très fortes</div>
<div class="steex-elevation-5">Ombres maximales</div>
```

### Cartes Material Design

```html
<!-- Carte standard -->
<div class="steex-card p-6">
  <h3>Titre de la carte</h3>
  <p>Contenu de la carte</p>
</div>

<!-- Carte avec effet hover -->
<div class="steex-card-hover p-6">
  <p>Carte cliquable</p>
</div>
```

### Boutons Material Design

```html
<!-- Bouton primaire -->
<button class="steex-btn-primary">
  Bouton primaire
</button>

<!-- Bouton secondaire -->
<button class="steex-btn-secondary">
  Bouton secondaire
</button>

<!-- Bouton outline -->
<button class="steex-btn-outline">
  Bouton outline
</button>
```

### Champs de saisie Material Design

```html
<input 
  type="text" 
  class="steex-input" 
  placeholder="Votre texte ici"
/>
```

### Cartes de statistiques

```html
<div class="steex-stat-card">
  <div class="steex-stat-card-gradient bg-primary"></div>
  <h3>Total</h3>
  <p class="text-3xl font-bold">1,234</p>
</div>
```

### Badges Material Design

```html
<span class="steex-badge-primary">Primary</span>
<span class="steex-badge-success">Success</span>
<span class="steex-badge-warning">Warning</span>
<span class="steex-badge-danger">Danger</span>
<span class="steex-badge-info">Info</span>
```

### Barre de progression

```html
<div class="steex-progress">
  <div class="steex-progress-bar" style="width: 60%"></div>
</div>
```

### Divider

```html
<div class="steex-divider"></div>
```

### Chip

```html
<span class="steex-chip">Tag</span>
<span class="steex-chip-hover">Tag cliquable</span>
```

### Conteneurs d'icônes

```html
<div class="steex-icon-container-sm bg-primary/10">
  <Icon class="w-5 h-5 text-primary" />
</div>

<div class="steex-icon-container-md bg-blue-500/10">
  <Icon class="w-6 h-6 text-blue-600" />
</div>

<div class="steex-icon-container-lg bg-green-500/10">
  <Icon class="w-7 h-7 text-green-600" />
</div>
```

### Tableaux Material Design

```html
<table class="steex-table">
  <thead class="steex-table-header">
    <tr>
      <th class="steex-table-cell">Colonne 1</th>
      <th class="steex-table-cell">Colonne 2</th>
    </tr>
  </thead>
  <tbody>
    <tr class="steex-table-row">
      <td class="steex-table-cell">Donnée 1</td>
      <td class="steex-table-cell">Donnée 2</td>
    </tr>
  </tbody>
</table>
```

### Avatars

```html
<div class="steex-avatar-sm">JD</div>
<div class="steex-avatar-md">JD</div>
<div class="steex-avatar-lg">JD</div>
```

### Effet Ripple

```html
<button class="steex-ripple steex-btn-primary">
  Bouton avec effet ripple
</button>
```

### Skeleton Loader

```html
<div class="steex-skeleton h-4 w-full mb-2"></div>
<div class="steex-skeleton h-4 w-3/4"></div>
```

### Tooltip

```html
<div class="relative group">
  <button>Hover me</button>
  <div class="steex-tooltip group-hover:steex-tooltip-visible">
    Tooltip text
  </div>
</div>
```

### Snackbar/Toast

```html
<div class="steex-snackbar">
  Message de notification
</div>
```

### FAB (Floating Action Button)

```html
<button class="steex-fab">
  <PlusIcon class="w-6 h-6" />
</button>
```

### Tabs Material Design

```html
<div class="steex-tabs">
  <button class="steex-tab">Tab 1</button>
  <button class="steex-tab steex-tab-active">Tab 2</button>
  <button class="steex-tab">Tab 3</button>
</div>
```

### Dialog/Modal

```html
<div class="steex-dialog-overlay">
  <div class="steex-dialog">
    <h2>Titre du dialog</h2>
    <p>Contenu du dialog</p>
  </div>
</div>
```

### Listes Material Design

```html
<div class="steex-list">
  <div class="steex-list-item">
    <Icon class="w-5 h-5" />
    <span>Item 1</span>
  </div>
  <div class="steex-list-item">
    <Icon class="w-5 h-5" />
    <span>Item 2</span>
  </div>
</div>
```

### Switch/Toggle

```html
<label class="steex-switch steex-switch-checked">
  <span class="steex-switch-thumb steex-switch-thumb-checked"></span>
</label>
```

### Stepper

```html
<div class="steex-stepper">
  <div class="steex-stepper-step">
    <div class="steex-stepper-circle steex-stepper-circle-active">1</div>
    <span>Étape 1</span>
  </div>
  <div class="steex-stepper-line steex-stepper-line-active"></div>
  <div class="steex-stepper-step">
    <div class="steex-stepper-circle">2</div>
    <span>Étape 2</span>
  </div>
</div>
```

## 🎨 Exemple complet : Carte de statistique

```html
<div class="steex-stat-card bg-gradient-to-br from-blue-50 to-blue-100/50 dark:from-blue-950/30 dark:to-blue-900/20">
  <div class="steex-stat-card-gradient bg-blue-500"></div>
  <div class="flex items-center justify-between relative z-10">
    <div class="flex-1">
      <p class="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">
        Total des propriétés
      </p>
      <p class="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
        1,234
      </p>
      <p class="text-xs text-gray-500 dark:text-gray-400">
        +12% vs mois dernier
      </p>
    </div>
    <div class="steex-icon-container-lg bg-blue-500/10">
      <HomeIcon class="w-7 h-7 text-blue-600 dark:text-blue-400" />
    </div>
  </div>
</div>
```

## 🔄 Conversion CSS vers Tailwind

Les classes suivantes ont été converties depuis le CSS Material Design original :

- **Ombres** : Système d'élévation Material Design (0-5)
- **Cartes** : Bordures arrondies, ombres, transitions
- **Boutons** : États hover, active, focus avec transitions
- **Inputs** : Focus ring, bordures, transitions
- **Badges** : Couleurs et variantes
- **Progress** : Barres de progression avec gradients
- **Tables** : Styles Material Design avec hover
- **Dialogs** : Overlay et animations
- **Tabs** : Navigation avec indicateur actif
- **Stepper** : Indicateur de progression multi-étapes

## 📝 Notes

- Toutes les classes supportent le mode sombre via `dark:`
- Les transitions sont configurées pour être fluides (200-300ms)
- Les ombres suivent les spécifications Material Design
- Les couleurs utilisent les variables CSS définies dans `tailwind.css`

## 🚀 Utilisation dans Vue

```vue
<template>
  <div class="steex-card p-6">
    <h3 class="text-xl font-semibold mb-4">Titre</h3>
    <button class="steex-btn-primary mt-4">
      Action
    </button>
  </div>
</template>
```

