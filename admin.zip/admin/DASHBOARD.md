# Dashboard Administrateur SaaS

## 📊 Vue d'ensemble

Le dashboard administrateur est conçu pour la gestion globale du système SaaS Real Estate. Il fournit une vue d'ensemble complète des statistiques, activités et actions rapides.

## 🎨 Composants créés

### 1. **DashboardHome.vue**
Composant principal du dashboard avec :
- **Statistiques principales** : 4 cartes de stats (Utilisateurs, Organisations, Propriétés, Sessions)
- **Actions rapides** : Boutons pour accéder rapidement aux différentes sections
- **Activité récente** : Liste des dernières actions sur la plateforme
- **Santé du système** : Statut des APIs et base de données
- **Nouveaux ce mois** : Statistiques de croissance mensuelle

### 2. **StatCard.vue**
Composant réutilisable pour afficher des statistiques :
- Support des icônes Lucide
- Indicateurs de croissance (pourcentage)
- Variantes de couleur (default, success, warning, danger, info)
- Animations au survol
- Gradient décoratif

### 3. **DashboardLayout.vue**
Layout moderne avec :
- **Sidebar** : Navigation principale avec icônes
- **Header** : Barre supérieure avec notifications et settings
- **Responsive** : Menu hamburger pour mobile
- **User section** : Affichage de l'utilisateur connecté avec déconnexion

### 4. **Store Dashboard** (`stores/dashboard.ts`)
Gestion de l'état des statistiques :
- `fetchStats()` : Récupère les statistiques depuis l'API
- `fetchRecentActivities()` : Récupère l'activité récente
- Cache avec expiration (5 minutes)
- Gestion d'erreurs avec fallback

### 5. **Composable useDashboard** (`composables/useDashboard.ts`)
Composable pour utiliser le dashboard :
- Chargement automatique au montage
- Auto-refresh toutes les minutes
- Nettoyage automatique au démontage

## 📈 Statistiques affichées

1. **Utilisateurs totaux** : Nombre total d'utilisateurs dans le système
2. **Organisations** : Nombre d'organisations
3. **Propriétés** : Nombre total de propriétés
4. **Sessions actives** : Nombre de sessions actives
5. **Nouveaux ce mois** : Utilisateurs et organisations créés ce mois
6. **Croissance** : Pourcentages de croissance (vs mois dernier)

## 🎯 Actions rapides

- Gérer les utilisateurs
- Gérer les organisations
- Gérer les propriétés
- Voir les analytics
- Paramètres de sécurité

## 🔄 Intégration API

Le dashboard tente de récupérer les données réelles depuis :
- `/api/users/me` : Pour obtenir l'organisation de l'utilisateur
- `/api/users/accessible/{orgId}` : Pour obtenir les utilisateurs accessibles
- `/api/organizations` : Pour obtenir les organisations (si disponible)

En cas d'erreur ou d'endpoint manquant, le dashboard utilise des données mock pour continuer à fonctionner.

## 🎨 Design

- **Design moderne** : Utilise Tailwind CSS avec thème dark/light
- **Responsive** : S'adapte à tous les écrans
- **Animations** : Transitions fluides et hover effects
- **Accessibilité** : Navigation clavier et ARIA labels

## 🚀 Prochaines étapes

1. Créer les endpoints backend dédiés pour les statistiques
2. Ajouter des graphiques (Chart.js ou Recharts)
3. Implémenter les notifications en temps réel
4. Ajouter des filtres de date pour les statistiques
5. Créer des widgets personnalisables

## 📝 Routes

- `/dashboard` : Page principale du dashboard
- `/dashboard/users` : Gestion des utilisateurs (à créer)
- `/dashboard/organizations` : Gestion des organisations (à créer)
- `/dashboard/properties` : Gestion des propriétés (à créer)
- `/dashboard/analytics` : Analytics détaillés (à créer)
- `/dashboard/security` : Paramètres de sécurité (à créer)

## 🔧 Configuration

Le dashboard utilise les variables d'environnement :
- `VITE_API_ADMIN_USERMNG_URL` : URL de l'API user management
- `VITE_API_ADMIN_PROPERTY_URL` : URL de l'API property
- `VITE_API_AUTH_URL` : URL de l'API auth

