package com.viridial.sass.organization.repositories;

import java.time.OffsetDateTime;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.viridial.sass.common.context.TenantContext;
import com.viridial.sass.organization.entities.UserEntity;
import com.viridial.sass.parameters.repositories.ParameterCustomRepository;

@Repository
public class UserCustomRepository {
    private final UserRepository userRepository;
    private final ParameterCustomRepository parameterCustomRepository;

    public UserCustomRepository(UserRepository userRepository, ParameterCustomRepository parameterCustomRepository) {
        this.userRepository = userRepository;
        this.parameterCustomRepository = parameterCustomRepository;
    }

    public Optional<UserEntity> findById(Long id) {
        return userRepository.findById(id);
    }

    public Optional<UserEntity> findByIdAndDeletedAtIsNull(Long id) {
        return userRepository.findByIdAndDeletedAtIsNull(id);
    }

    public Optional<UserEntity> findByInternalCodeAndTenantIdAndDeletedAtIsNull(String internalCode,
            Long tenantId) {
        return userRepository.findByInternalCodeAndTenantIdAndDeletedAtIsNull(internalCode, tenantId);
    }

    public Optional<UserEntity> findByInternalCodeAndTenantId(String internalCode, Long tenantId) {
        return userRepository.findByInternalCodeAndTenantId(internalCode, tenantId);
    }

    public UserEntity save(UserEntity entity) {
        String code = parameterCustomRepository.generateInternalCode("USER_ENTITY_SEQ", entity.getFirstName());
        entity.setInternalCode(code);
        return userRepository.save(entity);
    }

    public UserEntity update(UserEntity entity) {
        return userRepository.save(entity);
    }

    public void delete(UserEntity entity) {
        entity.setDeletedAt(OffsetDateTime.now());
        entity.setDeletedBy(TenantContext.get().getUserId());
        userRepository.save(entity);
    }
}
