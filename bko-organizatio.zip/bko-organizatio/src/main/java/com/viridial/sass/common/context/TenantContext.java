package com.viridial.sass.common.context;

public final class TenantContext {

    private static final ThreadLocal<Tenant> CURRENT = new ThreadLocal<>();

    private TenantContext() {
    }

    public static void set(Tenant tenant) {
        CURRENT.set(tenant);
    }

    public static Tenant get() {
        return CURRENT.get();
    }

    public static Long getTenantId() {
        return CURRENT.get() != null ? CURRENT.get().getId() : null;
    }

    public static void clear() {
        CURRENT.remove();
    }
}
