package com.viridial.sass.common.servlet;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.viridial.sass.organization.mapper.TenantMapper;
import com.viridial.sass.organization.repositories.TenantRepository;

@Configuration
public class TenantConfig {
    private final TenantMapper tenantMapper;

    public TenantConfig(TenantMapper tenantMapper) {
        this.tenantMapper = tenantMapper;
    }

    @Bean
    public FilterRegistrationBean<TenantResolutionFilter> tenantFilter(TenantRepository tenantRepository) {
        FilterRegistrationBean<TenantResolutionFilter> bean = new FilterRegistrationBean<>();
        bean.setFilter(new TenantResolutionFilter(tenantRepository, tenantMapper));
        bean.setOrder(1); // before security
        bean.addUrlPatterns("/*");

        return bean;
    }
}