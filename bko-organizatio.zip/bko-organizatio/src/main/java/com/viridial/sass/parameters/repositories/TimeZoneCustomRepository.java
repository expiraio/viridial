package com.viridial.sass.parameters.repositories;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.viridial.sass.common.context.TenantContext;
import com.viridial.sass.parameters.entities.TimeZoneEntity;

@Repository
public class TimeZoneCustomRepository {
    private final TimeZoneRepository timeZoneRepository;

    public TimeZoneCustomRepository(TimeZoneRepository timeZoneRepository) {
        this.timeZoneRepository = timeZoneRepository;
    }

    public List<TimeZoneEntity> findAll() {
        return timeZoneRepository.findAll();
    }

    public List<TimeZoneEntity> findByEnabledTrue() {
        return timeZoneRepository.findByEnabledTrue();
    }

    public Optional<TimeZoneEntity> findByZoneId(String zoneId) {
        return timeZoneRepository.findByZoneId(zoneId);
    }

    public List<TimeZoneEntity> findByCountryIso2(String countryIso2) {
        return timeZoneRepository.findByCountryIso2(countryIso2);
    }

    public TimeZoneEntity save(TimeZoneEntity entity) {
        return timeZoneRepository.save(entity);
    }

    public TimeZoneEntity update(TimeZoneEntity entity) {
        return timeZoneRepository.save(entity);
    }

    public void delete(TimeZoneEntity entity) {
        entity.setDeletedAt(OffsetDateTime.now());
        entity.setDeletedBy(TenantContext.get().getUserId());
        timeZoneRepository.save(entity);
    }
}
