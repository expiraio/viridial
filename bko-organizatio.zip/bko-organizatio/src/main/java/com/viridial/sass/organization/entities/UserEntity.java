package com.viridial.sass.organization.entities;

import java.time.OffsetDateTime;
import java.util.HashSet;
import java.util.Set;

import com.viridial.sass.common.entities.BaseEntity;
import com.viridial.sass.parameters.entities.CountryEntity;
import com.viridial.sass.parameters.entities.ParameterEntity;
import com.viridial.sass.parameters.entities.TimeZoneEntity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "org_user", uniqueConstraints = @UniqueConstraint(name = "org_user_inter_code", columnNames = "inter_code"))
public class UserEntity extends BaseEntity {

    @Column(name = "inter_code", unique = true, nullable = false)
    private String internalCode;
    @Column(name = "exter_code")
    private String externalCode;
    private String thumbnail;
    @Column(unique = true, name = "email", nullable = false)
    private String email;
    @Column(name = "password", nullable = false)
    private String password;
    @Column(name = "gender", nullable = false)
    private String gender;
    @Column(name = "first_name", nullable = false)
    private String firstName;
    @Column(name = "last_name")
    private String lastName;
    private String description;
    private String skills;
    private boolean active;
    @Column(name = "active_at")
    private OffsetDateTime activeAt;
    @Column(name = "last_login")
    private OffsetDateTime lastLogin;
    private boolean admin;
    private boolean sassAdmin;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<OrganizationUserEntity> organizations = new HashSet<>(0);

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "org_role_user", joinColumns = @JoinColumn(name = "user_fk"), inverseJoinColumns = @JoinColumn(name = "role_fk"))
    private Set<RoleEntity> roles = new HashSet<>(0);

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "job_title_fk", nullable = false, updatable = false, insertable = false)
    private ParameterEntity jobTitle;
    @Column(name = "job_title_fk")
    private Long jobTitleId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "time_zone_fk", nullable = false, updatable = false, insertable = false)
    private TimeZoneEntity timeZone;
    @Column(name = "time_zone_fk")
    private Long timeZoneId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "country_fk", nullable = false, updatable = false, insertable = false)
    private CountryEntity country;
    @Column(name = "country_fk")
    private Long countryId;

    public String getInternalCode() {
        return internalCode;
    }

    public void setInternalCode(String internalCode) {
        this.internalCode = internalCode;
    }

    public String getExternalCode() {
        return externalCode;
    }

    public void setExternalCode(String externalCode) {
        this.externalCode = externalCode;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public OffsetDateTime getActiveAt() {
        return activeAt;
    }

    public void setActiveAt(OffsetDateTime activeAt) {
        this.activeAt = activeAt;
    }

    public OffsetDateTime getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(OffsetDateTime lastLogin) {
        this.lastLogin = lastLogin;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public boolean isSassAdmin() {
        return sassAdmin;
    }

    public void setSassAdmin(boolean sassAdmin) {
        this.sassAdmin = sassAdmin;
    }

    public ParameterEntity getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(ParameterEntity jobTitle) {
        this.jobTitle = jobTitle;
    }

    public Long getJobTitleId() {
        return jobTitleId;
    }

    public void setJobTitleId(Long jobTitleId) {
        this.jobTitleId = jobTitleId;
    }

    public TimeZoneEntity getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(TimeZoneEntity timeZone) {
        this.timeZone = timeZone;
    }

    public Long getTimeZoneId() {
        return timeZoneId;
    }

    public void setTimeZoneId(Long timeZoneId) {
        this.timeZoneId = timeZoneId;
    }

    public CountryEntity getCountry() {
        return country;
    }

    public void setCountry(CountryEntity country) {
        this.country = country;
    }

    public Long getCountryId() {
        return countryId;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("UserEntity{");
        sb.append("internalCode=").append(internalCode);
        sb.append(", externalCode=").append(externalCode);
        sb.append(", email=").append(email);
        sb.append(", firstName=").append(firstName);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((internalCode == null) ? 0 : internalCode.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        UserEntity other = (UserEntity) obj;
        if (internalCode == null) {
            if (other.internalCode != null)
                return false;
        } else if (!internalCode.equals(other.internalCode))
            return false;
        return true;
    }

    public Set<OrganizationUserEntity> getOrganizations() {
        return organizations;
    }

    public void setOrganizations(Set<OrganizationUserEntity> organizations) {
        this.organizations = organizations;
    }

    public Set<RoleEntity> getRoles() {
        return roles;
    }

    public void setRoles(Set<RoleEntity> roles) {
        this.roles = roles;
    }
}
