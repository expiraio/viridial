package com.viridial.sass.parameters.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.viridial.sass.parameters.entities.ParameterEntity;

public interface ParameterRepository extends JpaRepository<ParameterEntity, Long> {

    List<ParameterEntity> findByActiveTrue();

    List<ParameterEntity> findByTypeIdAndActiveTrue(Long typeId);

    List<ParameterEntity> findByTypeId(Long typeId);

    Optional<ParameterEntity> findByInternalCodeAndActiveTrue(String internalCode);

    Optional<ParameterEntity> findByInternalCode(String internalCode);

}