package com.viridial.sass.organization.repositories;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.viridial.sass.common.context.TenantContext;
import com.viridial.sass.organization.entities.OrganizationEntity;
import com.viridial.sass.parameters.repositories.ParameterCustomRepository;

@Repository
public class OrganizationCustomRepository {
    private final OrganizationRepository organizationRepository;
    private final ParameterCustomRepository parameterCustomRepository;

    public OrganizationCustomRepository(OrganizationRepository organizationRepository,
            ParameterCustomRepository parameterCustomRepository) {
        this.organizationRepository = organizationRepository;
        this.parameterCustomRepository = parameterCustomRepository;
    }

    public Optional<OrganizationEntity> findById(Long id) {
        return organizationRepository.findById(id);
    }

    public Optional<OrganizationEntity> findByIdAndDeletedAtIsNull(Long id) {
        return organizationRepository.findByIdAndDeletedAtIsNull(id);
    }

    public List<OrganizationEntity> findByInternalCodeAndTenantIdAndDeletedAtIsNull(String internalCode) {
        return organizationRepository.findByInternalCodeAndTenantIdAndDeletedAtIsNull(internalCode,
                TenantContext.getTenantId());
    }

    public List<OrganizationEntity> findByInternalCodeAndTenantId(String internalCode, Long tenantId) {
        return organizationRepository.findByInternalCodeAndTenantId(internalCode, tenantId);
    }

    List<OrganizationEntity> findByParentId(Long parentId) {
        return organizationRepository.findByParentId(parentId);
    }

    List<OrganizationEntity> findByPathStartingWith(String path) {
        return organizationRepository.findByPathStartingWith(path);
    }

    List<OrganizationEntity> findByLevel(int level) {
        return organizationRepository.findByLevel(level);
    }

    int updatePathForSubtree(String oldPath, String newPath, int offset) {
        return organizationRepository.updatePathForSubtree(oldPath, newPath, offset);
    }

    int updatePathForSubtreeNative(String oldPath, String newPath, Long orgId) {
        return organizationRepository.updatePathForSubtreeNative(oldPath, newPath, orgId);
    }

    public OrganizationEntity save(OrganizationEntity entity) {
        String code = parameterCustomRepository.generateInternalCode("ORGANIZATION_ENTITY_SEQ", entity.getName());
        entity.setInternalCode(code);
        return organizationRepository.save(entity);
    }

    public OrganizationEntity update(OrganizationEntity entity) {
        return organizationRepository.save(entity);
    }

    public void delete(OrganizationEntity entity) {
        entity.setDeletedAt(OffsetDateTime.now());
        entity.setDeletedBy(TenantContext.get().getUserId());
        organizationRepository.save(entity);
    }
}
