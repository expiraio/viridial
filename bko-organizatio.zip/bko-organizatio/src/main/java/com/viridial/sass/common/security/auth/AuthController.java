package com.viridial.sass.common.security.auth;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.viridial.sass.common.security.auth.dto.AuthResponse;
import com.viridial.sass.common.security.auth.dto.LoginRequest;
import com.viridial.sass.common.security.auth.dto.SignupRequest;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final PasswordEncoder encoder;

    public AuthController(AuthService authService, PasswordEncoder encoder) {
        this.authService = authService;
        this.encoder = encoder;
    }

    @PostMapping("/signup")
    public AuthResponse signup(
            @RequestBody SignupRequest request,
            @RequestHeader("X-Tenant-ID") String tenantId) {

        return authService.signup(request, tenantId);
    }

    @PostMapping("/login")
    public AuthResponse login(
            @RequestBody LoginRequest request) {
        return authService.login(request);
    }
}
