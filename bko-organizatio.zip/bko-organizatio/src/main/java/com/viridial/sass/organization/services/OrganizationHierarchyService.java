package com.viridial.sass.organization.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.viridial.sass.organization.entities.OrganizationEntity;
import com.viridial.sass.organization.repositories.OrganizationRepository;

@Service
@Transactional(readOnly = true)
public class OrganizationHierarchyService {

    private final OrganizationRepository organizationRepository;

    public OrganizationHierarchyService(OrganizationRepository organizationRepository) {
        this.organizationRepository = organizationRepository;
    }

    @Transactional(readOnly = false)
    public void moveOrganization(
            OrganizationEntity org,
            OrganizationEntity newParent) {

        String oldPath = org.getPath();

        String newParentPath = newParent != null
                ? newParent.getPath() + newParent.getId() + "/"
                : "/";

        String newPath = newParentPath + org.getId() + "/";

        // Update root org itself
        org.setParent(newParent);
        org.setPath(newPath);
        org.setLevel(newParent != null ? newParent.getLevel() + 1 : 0);

        organizationRepository.save(org);

        // Update children paths in bulk
        updateChildrenPaths(org.getId(), oldPath, newPath);
    }

    @Transactional(readOnly = false)
    private void updateChildrenPaths(
            Long orgId,
            String oldPath,
            String newPath) {

        organizationRepository.updatePathForSubtree(
                oldPath,
                newPath,
                oldPath.length());
    }
}