package com.viridial.sass.parameters.entities;

import jakarta.persistence.*;

import com.viridial.sass.common.entities.BaseEntity;

@Entity
@Table(name = "conf_timezones", indexes = {
        @Index(name = "idx_timezone_zone", columnList = "zone_id"),
        @Index(name = "idx_timezone_country", columnList = "country_iso2")
})
public class TimeZoneEntity extends BaseEntity {

    /**
     * IANA Timezone ID (e.g. Africa/Casablanca)
     */
    @Column(name = "zone_id", nullable = false, unique = true)
    private String zoneId;

    /**
     * ISO-3166-1 alpha-2 (optional)
     */
    @Column(name = "country_iso2", length = 2)
    private String countryIso2;

    /**
     * Human-readable city/region
     */
    private String name;

    /**
     * Base UTC offset (+01:00)
     */
    @Column(name = "utc_offset", nullable = false, length = 6)
    private String utcOffset;

    /**
     * DST offset (+02:00 if applicable)
     */
    @Column(name = "dst_offset", length = 6)
    private String dstOffset;

    @Column(name = "observes_dst")
    private boolean observesDst;

    private boolean enabled = true;

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public String getCountryIso2() {
        return countryIso2;
    }

    public void setCountryIso2(String countryIso2) {
        this.countryIso2 = countryIso2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUtcOffset() {
        return utcOffset;
    }

    public void setUtcOffset(String utcOffset) {
        this.utcOffset = utcOffset;
    }

    public String getDstOffset() {
        return dstOffset;
    }

    public void setDstOffset(String dstOffset) {
        this.dstOffset = dstOffset;
    }

    public boolean isObservesDst() {
        return observesDst;
    }

    public void setObservesDst(boolean observesDst) {
        this.observesDst = observesDst;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("TimeZoneEntity{");
        sb.append("utc_offset=").append(utcOffset);
        sb.append(", zoneId=").append(zoneId);
        sb.append(", name=").append(name);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TimeZoneEntity other = (TimeZoneEntity) obj;
        if (getId() == null) {
            if (other.getId() != null)
                return false;
        } else if (!getId().equals(other.getId()))
            return false;
        return true;
    }
}