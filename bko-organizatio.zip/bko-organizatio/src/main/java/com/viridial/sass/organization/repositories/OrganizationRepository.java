package com.viridial.sass.organization.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.viridial.sass.organization.entities.OrganizationEntity;

public interface OrganizationRepository extends JpaRepository<OrganizationEntity, Long> {

    List<OrganizationEntity> findByInternalCodeAndTenantIdAndDeletedAtIsNull(String internalCode, Long tenantId);

    List<OrganizationEntity> findByInternalCodeAndTenantId(String internalCode, Long tenantId);

    Optional<OrganizationEntity> findByIdAndDeletedAtIsNull(Long id);

    List<OrganizationEntity> findByParentId(Long parentId);

    List<OrganizationEntity> findByPathStartingWith(String path);

    List<OrganizationEntity> findByLevel(int level);

    @Modifying
    @Query("""
                UPDATE OrganizationEntity o
                SET o.path = CONCAT(:newPath, SUBSTRING(o.path, :offset + 1))
                WHERE o.path LIKE CONCAT(:oldPath, '%')
                  AND o.id <> :orgId
            """)
    int updatePathForSubtree(
            @Param("oldPath") String oldPath,
            @Param("newPath") String newPath,
            @Param("offset") int offset);

    @Modifying
    @Query(value = """
                UPDATE org_org
                SET path = :newPath || SUBSTRING(path FROM LENGTH(:oldPath) + 1)
                WHERE path LIKE :oldPath || '%'
                  AND id <> :orgId
            """, nativeQuery = true)
    int updatePathForSubtreeNative(
            @Param("oldPath") String oldPath,
            @Param("newPath") String newPath,
            @Param("orgId") Long orgId);

}
