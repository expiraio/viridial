package com.viridial.sass.parameters.entities;

import java.time.LocalDate;
import java.time.OffsetDateTime;

import com.viridial.sass.common.entities.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "conf_parameter", uniqueConstraints = @UniqueConstraint(name = "conf_parameter_inter_code", columnNames = "inter_code"))
public class ParameterEntity extends BaseEntity {

    @Column(name = "inter_code", unique = true, nullable = false)
    private String internalCode;
    @Column(name = "exter_code")
    private String externalCode;
    private Long intValue;
    private String label;
    private String description;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "data_type_fk", nullable = false, updatable = false, insertable = false)
    private ParameterEntity dataType;
    @Column(name = "data_type_fk")
    private Long dataTypeId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "type_fk", nullable = true, updatable = false, insertable = false)
    private ParameterEntity type;
    @Column(name = "type_fk", nullable = true)
    private Long typeId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "parent_fk", nullable = true, updatable = false, insertable = false)
    private ParameterEntity parent;
    @Column(name = "parent_fk", nullable = true)
    private Long parentId;

    private boolean active;
    @Column(name = "active_at")
    private OffsetDateTime activeAt;

    @Column(name = "start_at")
    private LocalDate startAt;
    @Column(name = "end_at")
    private LocalDate endAt;

    public String getInternalCode() {
        return internalCode;
    }

    public void setInternalCode(String internalCode) {
        this.internalCode = internalCode;
    }

    public String getExternalCode() {
        return externalCode;
    }

    public void setExternalCode(String externalCode) {
        this.externalCode = externalCode;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ParameterEntity getDataType() {
        return dataType;
    }

    public void setDataType(ParameterEntity dataType) {
        this.dataType = dataType;
    }

    public Long getDataTypeId() {
        return dataTypeId;
    }

    public void setDataTypeId(Long dataTypeId) {
        this.dataTypeId = dataTypeId;
    }

    public ParameterEntity getType() {
        return type;
    }

    public void setType(ParameterEntity type) {
        this.type = type;
    }

    public Long getTypeId() {
        return typeId;
    }

    public ParameterEntity getParent() {
        return parent;
    }

    public void setParent(ParameterEntity parent) {
        this.parent = parent;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public OffsetDateTime getActiveAt() {
        return activeAt;
    }

    public void setActiveAt(OffsetDateTime activeAt) {
        this.activeAt = activeAt;
    }

    public LocalDate getStartAt() {
        return startAt;
    }

    public void setStartAt(LocalDate startAt) {
        this.startAt = startAt;
    }

    public LocalDate getEndAt() {
        return endAt;
    }

    public void setEndAt(LocalDate endAt) {
        this.endAt = endAt;
    }

    public Long getIntValue() {
        return intValue;
    }

    public void setIntValue(Long intValue) {
        this.intValue = intValue;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ParameterEntity{");
        sb.append("internalCode=").append(internalCode);
        sb.append(", externalCode=").append(externalCode);
        sb.append(", label=").append(label);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((internalCode == null) ? 0 : internalCode.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ParameterEntity other = (ParameterEntity) obj;
        if (internalCode == null) {
            if (other.internalCode != null)
                return false;
        } else if (!internalCode.equals(other.internalCode))
            return false;
        return true;
    }
}
