package com.viridial.sass.organization.entities;

import java.time.OffsetDateTime;
import java.util.HashSet;
import java.util.Set;

import com.viridial.sass.common.entities.BaseEntity;
import com.viridial.sass.common.utils.StringUtils;
import com.viridial.sass.parameters.entities.ParameterEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "org_org", uniqueConstraints = @UniqueConstraint(name = "org_org_inter_code", columnNames = "inter_code"))
public class OrganizationEntity extends BaseEntity {

    @Column(name = "inter_code", unique = true, nullable = false)
    private String internalCode;
    @Column(name = "exter_code")
    private String externalCode;
    private String thumbnail;
    private String name;
    private String description;
    private String skills;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "status_fk", nullable = false, updatable = false, insertable = false)
    private ParameterEntity status;
    @Column(name = "status_fk")
    private Long statusId;

    @Column(name = "status_at")
    private OffsetDateTime statust;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "type_fk", nullable = false, updatable = false, insertable = false)
    private ParameterEntity type;
    @Column(name = "type_fk")
    private Long typeId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "dept_fk", nullable = false, updatable = false, insertable = false)
    private ParameterEntity department;
    @Column(name = "dept_fk")
    private Long departmentId;

    /*
     * =========================
     * ORGANIZATION HIERARCHY
     * =========================
     */

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_fk", insertable = false, updatable = false)
    private OrganizationEntity parent;

    @Column(name = "parent_fk")
    private Long parentId;

    @OneToMany(mappedBy = "parent", fetch = FetchType.LAZY)
    private Set<OrganizationEntity> children = new HashSet<>(0);

    /**
     * Root = 0, child = parent.level + 1
     */
    @Column(name = "level", nullable = false)
    private int level;

    /**
     * Example: /1/3/8/
     * Fast subtree queries
     */
    @Column(name = "path", length = 255)
    private String path;

    public String getInternalCode() {
        return internalCode;
    }

    public void setInternalCode(String internalCode) {
        this.internalCode = internalCode;
    }

    public String getExternalCode() {
        return externalCode;
    }

    public void setExternalCode(String externalCode) {
        this.externalCode = externalCode;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public ParameterEntity getStatus() {
        return status;
    }

    public void setStatus(ParameterEntity status) {
        this.status = status;
    }

    public Long getStatusId() {
        return statusId;
    }

    public void setStatusId(Long statusId) {
        this.statusId = statusId;
    }

    public OffsetDateTime getStatust() {
        return statust;
    }

    public void setStatust(OffsetDateTime statust) {
        this.statust = statust;
    }

    public ParameterEntity getType() {
        return type;
    }

    public void setType(ParameterEntity type) {
        this.type = type;
    }

    public Long getTypeId() {
        return typeId;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    public ParameterEntity getDepartment() {
        return department;
    }

    public void setDepartment(ParameterEntity department) {
        this.department = department;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public OrganizationEntity getParent() {
        return parent;
    }

    public void setParent(OrganizationEntity parent) {
        this.parent = parent;
        this.parentId = parent != null ? parent.getId() : null;
        this.level = parent != null ? parent.getLevel() + 1 : 0;
        this.path = parent != null
                ? StringUtils.setEmpty(parent.getPath()) + parent.getId() + "/"
                : "/";
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public Set<OrganizationEntity> getChildren() {
        return children;
    }

    public void setChildren(Set<OrganizationEntity> children) {
        this.children = children;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("OrganizationEntity{");
        sb.append("internalCode=").append(internalCode);
        sb.append(", externalCode=").append(externalCode);
        sb.append(", name=").append(name);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((internalCode == null) ? 0 : internalCode.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OrganizationEntity other = (OrganizationEntity) obj;
        if (internalCode == null) {
            if (other.internalCode != null)
                return false;
        } else if (!internalCode.equals(other.internalCode))
            return false;
        return true;
    }
}
