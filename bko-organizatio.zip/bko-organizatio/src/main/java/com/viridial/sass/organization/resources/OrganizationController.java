package com.viridial.sass.organization.resources;

import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.viridial.sass.organization.forms.OrganizationForm;
import com.viridial.sass.organization.services.OrganizationService;

@RestController
@RequestMapping("/api/organization")
public class OrganizationController {

    private final OrganizationService organizationService;

    public OrganizationController(OrganizationService organizationService) {
        this.organizationService = organizationService;
    }

    @PostMapping("/find")
    public List<OrganizationForm> find(
            @RequestBody OrganizationForm request) {

        return organizationService.findByInternalCodeAndTenantIdAndDeletedAtIsNull(request.getInternalCode());
    }

}
