package com.viridial.sass.common.security.auth;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.viridial.sass.organization.entities.UserEntity;
import com.viridial.sass.organization.repositories.UserRepository;
import com.viridial.sass.organization.repositories.UserRepository;
import com.viridial.sass.common.security.JwtService;
import com.viridial.sass.common.security.auth.dto.AuthResponse;
import com.viridial.sass.common.security.auth.dto.LoginRequest;
import com.viridial.sass.common.security.auth.dto.SignupRequest;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder encoder;
    private final JwtService jwtService;

    public AuthService(UserRepository userRepository,
            PasswordEncoder encoder,
            JwtService jwtService) {
        this.userRepository = userRepository;
        this.encoder = encoder;
        this.jwtService = jwtService;
    }

    public AuthResponse signup(SignupRequest request, String tenantId) {

        if (userRepository.findByEmailAndDeletedAtIsNull(request.getEmail()).isPresent()) {
            throw new IllegalStateException("User already exists");
        }

        UserEntity user = new UserEntity();
        user.setEmail(request.getEmail());
        user.setPassword(encoder.encode(request.getPassword()));
        // user.setRole("USER");

        userRepository.save(user);

        return new AuthResponse(jwtService.generateToken(user, tenantId));
    }

    public AuthResponse login(LoginRequest request) {

        UserEntity user = userRepository.findByEmailAndDeletedAtIsNull(request.getEmail())
                .orElseThrow(() -> new BadCredentialsException("Invalid credentials"));

        if (!encoder.matches(request.getPassword(), user.getPassword())) {
            throw new BadCredentialsException("Invalid credentials");
        }

        return new AuthResponse(jwtService.generateToken(user));
    }
}