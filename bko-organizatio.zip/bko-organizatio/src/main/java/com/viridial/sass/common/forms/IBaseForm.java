package com.viridial.sass.common.forms;

import java.time.OffsetDateTime;

public interface IBaseForm {

    public Long getId();

    public void setId(Long id);

    public OffsetDateTime getCreatedAt();

    public void setCreatedAt(OffsetDateTime createdAt);

    public OffsetDateTime getUpdatedAt();

    public void setUpdatedAt(OffsetDateTime updatedAt);

    public OffsetDateTime getDeletedAt();

    public void setDeletedAt(OffsetDateTime deletedAt);

    public Long getCreatedBy();

    public void setCreatedBy(Long createdBy);

    public Long getUpdatedBy();

    public void setUpdatedBy(Long updatedBy);

    public Long getDeletedBy();

    public void setDeletedBy(Long deletedBy);

    public Long getTenantId();

    public void setTenantId(Long tenantId);

}
