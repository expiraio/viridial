package com.viridial.sass.organization.forms;

import java.time.OffsetDateTime;
import java.util.HashSet;
import java.util.Set;

import com.viridial.sass.common.forms.BaseForm;
import com.viridial.sass.organization.entities.OrganizationEntity;
import com.viridial.sass.organization.entities.RoleEntity;

public class UserForm extends BaseForm {

    private String internalCode;
    private String externalCode;
    private String thumbnail;
    private String email;
    private String password;
    private String gender;
    private String firstName;
    private String lastName;
    private String description;
    private String skills;
    private boolean active;
    private OffsetDateTime activeAt;
    private OffsetDateTime lastLogin;
    private boolean admin;
    private boolean sassAdmin;
    private String jobTitleInternalCode;
    private String jobTitleLabel;
    private Long jobTitleId;
    private String timeZoneName;
    private String timeZoneCountryIso2;
    private String timeZoneZoneId;
    private Long timeZoneId;
    private String countryName;
    private String countryRegion;
    private String countryIso2;
    private String countryIso3;
    private Long countryId;
    private Set<OrganizationForm> organizations = new HashSet<>(0);
    private Set<RoleForm> roles = new HashSet<>(0);

    public String getInternalCode() {
        return internalCode;
    }

    public void setInternalCode(String internalCode) {
        this.internalCode = internalCode;
    }

    public String getExternalCode() {
        return externalCode;
    }

    public void setExternalCode(String externalCode) {
        this.externalCode = externalCode;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public OffsetDateTime getActiveAt() {
        return activeAt;
    }

    public void setActiveAt(OffsetDateTime activeAt) {
        this.activeAt = activeAt;
    }

    public OffsetDateTime getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(OffsetDateTime lastLogin) {
        this.lastLogin = lastLogin;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public boolean isSassAdmin() {
        return sassAdmin;
    }

    public void setSassAdmin(boolean sassAdmin) {
        this.sassAdmin = sassAdmin;
    }

    public String getJobTitleInternalCode() {
        return jobTitleInternalCode;
    }

    public void setJobTitleInternalCode(String jobTitleInternalCode) {
        this.jobTitleInternalCode = jobTitleInternalCode;
    }

    public String getJobTitleLabel() {
        return jobTitleLabel;
    }

    public void setJobTitleLabel(String jobTitleLabel) {
        this.jobTitleLabel = jobTitleLabel;
    }

    public Long getJobTitleId() {
        return jobTitleId;
    }

    public void setJobTitleId(Long jobTitleId) {
        this.jobTitleId = jobTitleId;
    }

    public String getTimeZoneName() {
        return timeZoneName;
    }

    public void setTimeZoneName(String timeZoneName) {
        this.timeZoneName = timeZoneName;
    }

    public String getTimeZoneCountryIso2() {
        return timeZoneCountryIso2;
    }

    public void setTimeZoneCountryIso2(String timeZoneCountryIso2) {
        this.timeZoneCountryIso2 = timeZoneCountryIso2;
    }

    public String getTimeZoneZoneId() {
        return timeZoneZoneId;
    }

    public void setTimeZoneZoneId(String timeZoneZoneId) {
        this.timeZoneZoneId = timeZoneZoneId;
    }

    public Long getTimeZoneId() {
        return timeZoneId;
    }

    public void setTimeZoneId(Long timeZoneId) {
        this.timeZoneId = timeZoneId;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCountryRegion() {
        return countryRegion;
    }

    public void setCountryRegion(String countryRegion) {
        this.countryRegion = countryRegion;
    }

    public String getCountryIso2() {
        return countryIso2;
    }

    public void setCountryIso2(String countryIso2) {
        this.countryIso2 = countryIso2;
    }

    public String getCountryIso3() {
        return countryIso3;
    }

    public void setCountryIso3(String countryIso3) {
        this.countryIso3 = countryIso3;
    }

    public Long getCountryId() {
        return countryId;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("UserForm{");
        sb.append("internalCode=").append(internalCode);
        sb.append(", externalCode=").append(externalCode);
        sb.append(", email=").append(email);
        sb.append(", firstName=").append(firstName);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((internalCode == null) ? 0 : internalCode.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        UserForm other = (UserForm) obj;
        if (internalCode == null) {
            if (other.internalCode != null)
                return false;
        } else if (!internalCode.equals(other.internalCode))
            return false;
        return true;
    }

    public Set<OrganizationForm> getOrganizations() {
        return organizations;
    }

    public void setOrganizations(Set<OrganizationForm> organizations) {
        this.organizations = organizations;
    }

}
