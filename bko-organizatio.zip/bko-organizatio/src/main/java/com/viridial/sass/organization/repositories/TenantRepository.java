package com.viridial.sass.organization.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.viridial.sass.organization.entities.TenantEntity;

public interface TenantRepository extends JpaRepository<TenantEntity, Long> {

    Optional<TenantEntity> findByInternalCodeAndDeletedAtIsNull(String internalCode);

    Optional<TenantEntity> findByInternalCode(String internalCode);

    Optional<TenantEntity> findByIdAndDeletedAtIsNull(Long id);

}
