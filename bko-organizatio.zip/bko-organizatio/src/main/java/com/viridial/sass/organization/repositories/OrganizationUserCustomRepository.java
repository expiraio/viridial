package com.viridial.sass.organization.repositories;

import java.time.OffsetDateTime;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.viridial.sass.common.context.TenantContext;
import com.viridial.sass.organization.entities.OrganizationUserEntity;

@Repository
public class OrganizationUserCustomRepository {
    private final OrganizationUserRepository organizationUserRepository;

    public OrganizationUserCustomRepository(OrganizationUserRepository organizationUserRepository) {
        this.organizationUserRepository = organizationUserRepository;
    }

    public Optional<OrganizationUserEntity> findById(Long id) {
        return organizationUserRepository.findById(id);
    }

    public Optional<OrganizationUserEntity> findByIdAndDeletedAtIsNull(Long id) {
        return organizationUserRepository.findByIdAndDeletedAtIsNull(id);
    }

    public Optional<OrganizationUserEntity> findByUserIdAndTenantIdAndDeletedAtIsNull(Long userId, Long tenantId) {
        return organizationUserRepository.findByUserIdAndTenantIdAndDeletedAtIsNull(userId, tenantId);
    }

    public Optional<OrganizationUserEntity> findByOrganizationIdAndTenantIdAndDeletedAtIsNull(Long organizationId,
            Long tenantId) {
        return organizationUserRepository.findByOrganizationIdAndTenantIdAndDeletedAtIsNull(organizationId, tenantId);
    }

    public OrganizationUserEntity save(OrganizationUserEntity entity) {
        return organizationUserRepository.save(entity);
    }

    public OrganizationUserEntity update(OrganizationUserEntity entity) {
        return organizationUserRepository.save(entity);
    }

    public void delete(OrganizationUserEntity entity) {
        entity.setDeletedAt(OffsetDateTime.now());
        entity.setDeletedBy(TenantContext.get().getUserId());
        organizationUserRepository.save(entity);
    }
}
