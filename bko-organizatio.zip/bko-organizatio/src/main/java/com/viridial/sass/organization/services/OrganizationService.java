package com.viridial.sass.organization.services;

import java.time.OffsetDateTime;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.viridial.sass.organization.entities.OrganizationEntity;
import com.viridial.sass.organization.entities.OrganizationUserEntity;
import com.viridial.sass.organization.forms.OrganizationForm;
import com.viridial.sass.organization.mapper.OrganizationMapper;
import com.viridial.sass.organization.repositories.OrganizationCustomRepository;
import com.viridial.sass.organization.repositories.OrganizationUserCustomRepository;

@Service
@Transactional(readOnly = true)
public class OrganizationService {

    private final OrganizationCustomRepository organizationCustomRepository;
    private final OrganizationMapper organizationMapper;

    public OrganizationService(OrganizationCustomRepository organizationCustomRepository,
            OrganizationMapper organizationMapper) {
        this.organizationCustomRepository = organizationCustomRepository;
        this.organizationMapper = organizationMapper;
    }

    @Transactional(readOnly = true)
    public List<OrganizationForm> findByInternalCodeAndTenantIdAndDeletedAtIsNull(String internalCode) {
        List<OrganizationEntity> list = organizationCustomRepository
                .findByInternalCodeAndTenantIdAndDeletedAtIsNull(internalCode);

        return organizationMapper.toForm(list);
    }

}
