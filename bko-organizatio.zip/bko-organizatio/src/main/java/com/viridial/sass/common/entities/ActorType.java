package com.viridial.sass.common.entities;

public enum ActorType {
    SYSTEM,
    TENANT
}
