package com.viridial.sass.organization.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.viridial.sass.organization.entities.TenantEntity;
import com.viridial.sass.organization.forms.TenantForm;
import com.viridial.sass.organization.mapper.TenantMapper;
import com.viridial.sass.organization.repositories.TenantCustomRepository;

@Service
@Transactional(readOnly = true)
public class TenantService {

    private final TenantCustomRepository tenantCustomRepository;
    private final TenantMapper tenantMapper;

    public TenantService(TenantCustomRepository tenantCustomRepository, TenantMapper tenantMapper) {
        this.tenantCustomRepository = tenantCustomRepository;
        this.tenantMapper = tenantMapper;
    }

    @Transactional(readOnly = true)
    public TenantForm findByInternalCodeAndDeletedAtIsNull(String internalCode) {
        TenantEntity entity = tenantCustomRepository.findByInternalCodeAndDeletedAtIsNull(internalCode)
                .orElseThrow(() -> new IllegalStateException("Tenant not found: " + internalCode));

        return tenantMapper.toForm(entity);
    }
}
