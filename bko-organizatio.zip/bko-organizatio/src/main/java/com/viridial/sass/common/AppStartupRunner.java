package com.viridial.sass.common;

import java.time.LocalDate;
import java.time.OffsetDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.viridial.sass.organization.entities.OrganizationEntity;
import com.viridial.sass.organization.entities.OrganizationUserEntity;
import com.viridial.sass.organization.entities.TenantEntity;
import com.viridial.sass.organization.entities.UserEntity;
import com.viridial.sass.organization.repositories.OrganizationCustomRepository;
import com.viridial.sass.organization.repositories.OrganizationUserRepository;
import com.viridial.sass.organization.repositories.TenantCustomRepository;
import com.viridial.sass.organization.repositories.UserCustomRepository;
import com.viridial.sass.parameters.entities.ParameterEntity;
import com.viridial.sass.parameters.repositories.ParameterCustomRepository;

@Component
public class AppStartupRunner implements CommandLineRunner {

    @Autowired
    TenantCustomRepository tenantCustomRepository;
    @Autowired
    OrganizationCustomRepository organizationCustomRepository;
    @Autowired
    UserCustomRepository userCustomRepository;
    @Autowired
    OrganizationUserRepository organizationUserRepository;
    @Autowired
    ParameterCustomRepository parameterCustomRepository;
    @Autowired
    private PasswordEncoder encoder;

    @Override
    public void run(String... args) {
        ParameterEntity orgType = new ParameterEntity();
        orgType.setLabel("Organization Type");
        orgType.setDescription("Organization Type");
        orgType.setActive(true);
        orgType.setActiveAt(OffsetDateTime.now());
        orgType.setStartAt(LocalDate.of(2000, 1, 1));
        orgType.setEndAt(LocalDate.of(9000, 1, 1));
        parameterCustomRepository.save(orgType);

        ParameterEntity orgTypeFunctional = new ParameterEntity();
        orgTypeFunctional.setLabel("Functional");
        orgTypeFunctional.setDescription("Organization Type Functional");
        orgTypeFunctional.setActive(true);
        orgTypeFunctional.setActiveAt(OffsetDateTime.now());
        orgTypeFunctional.setStartAt(LocalDate.of(2000, 1, 1));
        orgTypeFunctional.setEndAt(LocalDate.of(9000, 1, 1));
        orgTypeFunctional.setParentId(orgType.getId());
        parameterCustomRepository.save(orgTypeFunctional);

        ParameterEntity orgTypeProject = new ParameterEntity();
        orgTypeProject.setLabel("Project");
        orgTypeProject.setDescription("Organization Type Project");
        orgTypeProject.setActive(true);
        orgTypeProject.setActiveAt(OffsetDateTime.now());
        orgTypeProject.setStartAt(LocalDate.of(2000, 1, 1));
        orgTypeProject.setEndAt(LocalDate.of(9000, 1, 1));
        orgTypeProject.setParentId(orgType.getId());
        parameterCustomRepository.save(orgTypeProject);

        ParameterEntity orgTypeOther = new ParameterEntity();
        orgTypeOther.setLabel("Other");
        orgTypeOther.setDescription("Organization Type Other");
        orgTypeOther.setActive(true);
        orgTypeOther.setActiveAt(OffsetDateTime.now());
        orgTypeOther.setStartAt(LocalDate.of(2000, 1, 1));
        orgTypeOther.setEndAt(LocalDate.of(9000, 1, 1));
        orgTypeOther.setParentId(orgType.getId());
        parameterCustomRepository.save(orgTypeOther);

        ParameterEntity orgDepartement = new ParameterEntity();
        orgDepartement.setLabel("Department");
        orgDepartement.setDescription("Organization Department");
        orgDepartement.setActive(true);
        orgDepartement.setActiveAt(OffsetDateTime.now());
        orgDepartement.setStartAt(LocalDate.of(2000, 1, 1));
        orgDepartement.setEndAt(LocalDate.of(9000, 1, 1));
        parameterCustomRepository.save(orgDepartement);

        ParameterEntity orgDepartementProduct = new ParameterEntity();
        orgDepartementProduct.setLabel("Product");
        orgDepartementProduct.setDescription("Overseeing product development and lifecycle");
        orgDepartementProduct.setActive(true);
        orgDepartementProduct.setActiveAt(OffsetDateTime.now());
        orgDepartementProduct.setStartAt(LocalDate.of(2000, 1, 1));
        orgDepartementProduct.setEndAt(LocalDate.of(9000, 1, 1));
        orgDepartementProduct.setParentId(orgDepartement.getId());
        parameterCustomRepository.save(orgDepartementProduct);

        ParameterEntity orgDepartementMarketing = new ParameterEntity();
        orgDepartementMarketing.setLabel("Marketing");
        orgDepartementMarketing.setDescription("Developing campaigns, market analysis");
        orgDepartementMarketing.setActive(true);
        orgDepartementMarketing.setActiveAt(OffsetDateTime.now());
        orgDepartementMarketing.setStartAt(LocalDate.of(2000, 1, 1));
        orgDepartementMarketing.setEndAt(LocalDate.of(9000, 1, 1));
        orgDepartementMarketing.setParentId(orgDepartement.getId());
        parameterCustomRepository.save(orgDepartementMarketing);

        ParameterEntity orgDepartementITSupport = new ParameterEntity();
        orgDepartementITSupport.setLabel("IT Support");
        orgDepartementITSupport.setDescription("Maintaining IT infrastructure, user support");
        orgDepartementITSupport.setActive(true);
        orgDepartementITSupport.setActiveAt(OffsetDateTime.now());
        orgDepartementITSupport.setStartAt(LocalDate.of(2000, 1, 1));
        orgDepartementITSupport.setEndAt(LocalDate.of(9000, 1, 1));
        orgDepartementITSupport.setParentId(orgDepartement.getId());
        parameterCustomRepository.save(orgDepartementITSupport);

        ParameterEntity orgDepartementComercial = new ParameterEntity();
        orgDepartementComercial.setLabel("Sales Division");
        orgDepartementComercial.setDescription("Customer relations, sales strategy execution");
        orgDepartementComercial.setActive(true);
        orgDepartementComercial.setActiveAt(OffsetDateTime.now());
        orgDepartementComercial.setStartAt(LocalDate.of(2000, 1, 1));
        orgDepartementComercial.setEndAt(LocalDate.of(9000, 1, 1));
        orgDepartementComercial.setParentId(orgDepartement.getId());
        parameterCustomRepository.save(orgDepartementComercial);

        ParameterEntity orgStatus = new ParameterEntity();
        orgStatus.setLabel("Status");
        orgStatus.setDescription("Organization status");
        orgStatus.setActive(true);
        orgStatus.setActiveAt(OffsetDateTime.now());
        orgStatus.setStartAt(LocalDate.of(2000, 1, 1));
        orgStatus.setEndAt(LocalDate.of(9000, 1, 1));
        parameterCustomRepository.save(orgStatus);

        ParameterEntity orgStatusActive = new ParameterEntity();
        orgStatusActive.setLabel("Active");
        orgStatusActive.setDescription("Organization status Active");
        orgStatusActive.setActive(true);
        orgStatusActive.setActiveAt(OffsetDateTime.now());
        orgStatusActive.setStartAt(LocalDate.of(2000, 1, 1));
        orgStatusActive.setEndAt(LocalDate.of(9000, 1, 1));
        orgStatusActive.setParentId(orgStatus.getId());
        parameterCustomRepository.save(orgStatusActive);

        ParameterEntity orgStatusInActive = new ParameterEntity();
        orgStatusInActive.setLabel("Inactive");
        orgStatusInActive.setDescription("Organization status Inactive");
        orgStatusInActive.setActive(true);
        orgStatusInActive.setActiveAt(OffsetDateTime.now());
        orgStatusInActive.setStartAt(LocalDate.of(2000, 1, 1));
        orgStatusInActive.setEndAt(LocalDate.of(9000, 1, 1));
        orgStatusInActive.setParentId(orgStatus.getId());
        parameterCustomRepository.save(orgStatusActive);

        TenantEntity viridial = new TenantEntity();
        viridial.setName("viridial");
        viridial.setDescription("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        viridial.setActive(true);
        viridial.setSkills("sass, realestate, dev");
        tenantCustomRepository.save(viridial);

        OrganizationEntity viridialInformatique = new OrganizationEntity();
        viridialInformatique.setName("Informatique");
        viridialInformatique.setDescription("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        viridialInformatique.setStatusId(orgStatusActive.getId());
        viridialInformatique.setSkills("sass, informatique");
        viridialInformatique.setTenantId(1l);
        viridialInformatique.setDepartmentId(orgDepartementITSupport.getId());
        viridialInformatique.setTypeId(orgTypeProject.getId());
        organizationCustomRepository.save(viridialInformatique);

        UserEntity adminViridialInformatique = new UserEntity();
        adminViridialInformatique.setFirstName("Sassa");
        adminViridialInformatique.setLastName("Hicham");
        adminViridialInformatique.setActive(true);
        adminViridialInformatique.setActiveAt(OffsetDateTime.now());
        adminViridialInformatique.setEmail("sass.hicham@gmail.com");
        adminViridialInformatique.setPassword(encoder.encode("password"));
        adminViridialInformatique.setDescription("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        adminViridialInformatique.setGender("MR");
        adminViridialInformatique.setAdmin(true);
        adminViridialInformatique.setSassAdmin(true);
        adminViridialInformatique.setTenantId(1l);
        userCustomRepository.save(adminViridialInformatique);

        OrganizationUserEntity adminViridialInformatiqueRel = new OrganizationUserEntity();
        adminViridialInformatiqueRel.setActive(true);
        adminViridialInformatiqueRel.setActiveAt(OffsetDateTime.now());
        adminViridialInformatiqueRel.setOrganizationId(viridialInformatique.getId());
        adminViridialInformatiqueRel.setUserId(adminViridialInformatique.getId());
        adminViridialInformatiqueRel.setTenantId(1l);
        organizationUserRepository.save(adminViridialInformatiqueRel);

        UserEntity adminViridialInformatiqueAdmin = new UserEntity();
        adminViridialInformatiqueAdmin.setFirstName("supper");
        adminViridialInformatiqueAdmin.setLastName("admin");
        adminViridialInformatiqueAdmin.setActive(true);
        adminViridialInformatiqueAdmin.setActiveAt(OffsetDateTime.now());
        adminViridialInformatiqueAdmin.setEmail("h.sassa@yahoo.fr");
        adminViridialInformatiqueAdmin.setPassword(encoder.encode("password"));
        adminViridialInformatiqueAdmin.setDescription("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        adminViridialInformatiqueAdmin.setGender("MR");
        adminViridialInformatiqueAdmin.setAdmin(true);
        adminViridialInformatiqueAdmin.setSassAdmin(true);
        adminViridialInformatiqueAdmin.setTenantId(1l);
        userCustomRepository.save(adminViridialInformatiqueAdmin);

        OrganizationUserEntity adminViridialInformatiqueAdminRel = new OrganizationUserEntity();
        adminViridialInformatiqueAdminRel.setActive(true);
        adminViridialInformatiqueAdminRel.setActiveAt(OffsetDateTime.now());
        adminViridialInformatiqueAdminRel.setOrganizationId(viridialInformatique.getId());
        adminViridialInformatiqueAdminRel.setUserId(adminViridialInformatiqueAdmin.getId());
        adminViridialInformatiqueAdminRel.setTenantId(1l);
        organizationUserRepository.save(adminViridialInformatiqueAdminRel);

        OrganizationEntity viridialCommercial = new OrganizationEntity();
        viridialCommercial.setName("Commercial");
        viridialCommercial.setDescription("Commercial lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        viridialCommercial.setStatusId(orgStatusActive.getId());
        viridialCommercial.setSkills("realestate, Commercial");
        viridialCommercial.setStatusId(orgStatusActive.getId());
        viridialCommercial.setTenantId(1l);
        viridialCommercial.setParentId(viridialInformatique.getId());
        viridialCommercial.setParent(viridialInformatique);
        viridialCommercial.setDepartmentId(orgDepartementComercial.getId());
        viridialCommercial.setTypeId(orgTypeFunctional.getId());
        organizationCustomRepository.save(viridialCommercial);

        UserEntity adminViridialCommercial = new UserEntity();
        adminViridialCommercial.setFirstName("Toto");
        adminViridialCommercial.setLastName("Toto");
        adminViridialCommercial.setActive(true);
        adminViridialCommercial.setActiveAt(OffsetDateTime.now());
        adminViridialCommercial.setEmail("toto@viridial.com");
        adminViridialCommercial.setPassword(encoder.encode("password"));
        adminViridialCommercial.setDescription("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        adminViridialCommercial.setGender("MR");
        adminViridialCommercial.setAdmin(false);
        adminViridialCommercial.setTenantId(1l);
        userCustomRepository.save(adminViridialCommercial);

        OrganizationUserEntity adminViridialCommercialRel = new OrganizationUserEntity();
        adminViridialCommercialRel.setActive(true);
        adminViridialCommercialRel.setActiveAt(OffsetDateTime.now());
        adminViridialCommercialRel.setOrganizationId(viridialCommercial.getId());
        adminViridialCommercialRel.setUserId(adminViridialCommercial.getId());
        adminViridialCommercialRel.setTenantId(1l);
        organizationUserRepository.save(adminViridialCommercialRel);

        OrganizationEntity viridialMarketing = new OrganizationEntity();
        viridialMarketing.setName("Marketing");
        viridialMarketing.setDescription("Marketing lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        viridialMarketing.setStatusId(orgStatusActive.getId());
        viridialMarketing.setSkills("realestate, Marketing");
        viridialMarketing.setTenantId(1l);
        viridialMarketing.setParentId(viridialInformatique.getId());
        viridialMarketing.setParent(viridialInformatique);
        viridialMarketing.setDepartmentId(orgDepartementMarketing.getId());
        viridialMarketing.setTypeId(orgTypeFunctional.getId());
        organizationCustomRepository.save(viridialMarketing);

        UserEntity adminViridialMarketing = new UserEntity();
        adminViridialMarketing.setFirstName("Titi");
        adminViridialMarketing.setLastName("Titi");
        adminViridialMarketing.setActive(true);
        adminViridialMarketing.setActiveAt(OffsetDateTime.now());
        adminViridialMarketing.setEmail("titi@viridial.com");
        adminViridialMarketing.setPassword(encoder.encode("password"));
        adminViridialMarketing.setDescription("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        adminViridialMarketing.setGender("MDM");
        adminViridialMarketing.setAdmin(false);
        adminViridialMarketing.setTenantId(1l);
        userCustomRepository.save(adminViridialMarketing);

        OrganizationUserEntity adminViridialMarketingRel = new OrganizationUserEntity();
        adminViridialMarketingRel.setActive(true);
        adminViridialMarketingRel.setActiveAt(OffsetDateTime.now());
        adminViridialMarketingRel.setOrganizationId(viridialMarketing.getId());
        adminViridialMarketingRel.setUserId(adminViridialMarketing.getId());
        adminViridialMarketingRel.setTenantId(1l);
        organizationUserRepository.save(adminViridialMarketingRel);

        TenantEntity company = new TenantEntity();
        company.setName("viridial");
        company.setDescription("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        company.setActive(true);
        company.setSkills("sass, realestate, dev");
        tenantCustomRepository.save(company);

        OrganizationEntity companyInformatique = new OrganizationEntity();
        companyInformatique.setName("Informatique");
        companyInformatique.setDescription("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        companyInformatique.setStatusId(orgStatusActive.getId());
        companyInformatique.setSkills("sass, informatique");
        companyInformatique.setTenantId(2l);
        companyInformatique.setParentId(viridialInformatique.getId());
        companyInformatique.setParent(viridialInformatique);
        companyInformatique.setDepartmentId(orgDepartementITSupport.getId());
        companyInformatique.setTypeId(orgTypeFunctional.getId());
        organizationCustomRepository.save(companyInformatique);

        UserEntity adminCompanyInformatique = new UserEntity();
        adminCompanyInformatique.setFirstName("Mark");
        adminCompanyInformatique.setLastName("jean");
        adminCompanyInformatique.setActive(true);
        adminCompanyInformatique.setActiveAt(OffsetDateTime.now());
        adminCompanyInformatique.setEmail("mark@viridial.com");
        adminCompanyInformatique.setPassword(encoder.encode("password"));
        adminCompanyInformatique.setDescription("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        adminCompanyInformatique.setGender("MR");
        adminCompanyInformatique.setAdmin(true);
        adminCompanyInformatique.setSassAdmin(false);
        adminCompanyInformatique.setTenantId(2l);
        userCustomRepository.save(adminCompanyInformatique);

        OrganizationUserEntity adminCompanyInformatiqueRel = new OrganizationUserEntity();
        adminCompanyInformatiqueRel.setActive(true);
        adminCompanyInformatiqueRel.setActiveAt(OffsetDateTime.now());
        adminCompanyInformatiqueRel.setOrganizationId(companyInformatique.getId());
        adminCompanyInformatiqueRel.setUserId(adminCompanyInformatique.getId());
        adminCompanyInformatiqueRel.setTenantId(2l);
        organizationUserRepository.save(adminCompanyInformatiqueRel);

        OrganizationEntity companyCommercial = new OrganizationEntity();
        companyCommercial.setName("Commercial");
        companyCommercial.setDescription("Commercial lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        companyCommercial.setStatusId(orgStatusActive.getId());
        companyCommercial.setSkills("realestate, Commercial");
        companyCommercial.setTenantId(2l);
        companyCommercial.setParentId(companyInformatique.getId());
        companyCommercial.setParent(companyInformatique);
        companyCommercial.setDepartmentId(orgDepartementComercial.getId());
        companyCommercial.setTypeId(orgTypeFunctional.getId());
        organizationCustomRepository.save(companyCommercial);

        UserEntity adminCompanyCommercial = new UserEntity();
        adminCompanyCommercial.setFirstName("Frank");
        adminCompanyCommercial.setLastName("match");
        adminCompanyCommercial.setActive(true);
        adminCompanyCommercial.setActiveAt(OffsetDateTime.now());
        adminCompanyCommercial.setEmail("frank@viridial.com");
        adminCompanyCommercial.setPassword(encoder.encode("password"));
        adminCompanyCommercial.setDescription("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        adminCompanyCommercial.setGender("MR");
        adminCompanyCommercial.setAdmin(false);
        adminCompanyCommercial.setTenantId(2l);
        userCustomRepository.save(adminCompanyCommercial);

        OrganizationUserEntity adminCompanyCommercialRel = new OrganizationUserEntity();
        adminCompanyCommercialRel.setActive(true);
        adminCompanyCommercialRel.setActiveAt(OffsetDateTime.now());
        adminCompanyCommercialRel.setOrganizationId(companyCommercial.getId());
        adminCompanyCommercialRel.setUserId(adminCompanyCommercial.getId());
        adminCompanyCommercialRel.setTenantId(2l);
        organizationUserRepository.save(adminCompanyCommercialRel);

        OrganizationEntity companyMarketing = new OrganizationEntity();
        companyMarketing.setName("Marketing");
        companyMarketing.setDescription("Marketing lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        companyMarketing.setStatusId(orgStatusActive.getId());
        companyMarketing.setSkills("realestate, Marketing");
        companyMarketing.setTenantId(2l);
        companyMarketing.setParent(companyInformatique);
        companyMarketing.setParentId(companyInformatique.getId());
        companyMarketing.setDepartmentId(orgDepartementMarketing.getId());
        companyMarketing.setTypeId(orgTypeFunctional.getId());
        organizationCustomRepository.save(companyMarketing);

        UserEntity adminCompanyMarketing = new UserEntity();
        adminCompanyMarketing.setFirstName("Sarah");
        adminCompanyMarketing.setLastName("boser");
        adminCompanyMarketing.setActive(true);
        adminCompanyMarketing.setActiveAt(OffsetDateTime.now());
        adminCompanyMarketing.setEmail("boser@viridial.com");
        adminCompanyMarketing.setPassword(encoder.encode("password"));
        adminCompanyMarketing.setDescription("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        adminCompanyMarketing.setGender("MDM");
        adminCompanyMarketing.setAdmin(false);
        adminCompanyMarketing.setTenantId(2l);
        userCustomRepository.save(adminCompanyMarketing);

        OrganizationUserEntity adminCompanyMarketingRel = new OrganizationUserEntity();
        adminCompanyMarketingRel.setActive(true);
        adminCompanyMarketingRel.setActiveAt(OffsetDateTime.now());
        adminCompanyMarketingRel.setOrganizationId(companyMarketing.getId());
        adminCompanyMarketingRel.setUserId(adminCompanyMarketing.getId());
        adminCompanyMarketingRel.setTenantId(2l);
        organizationUserRepository.save(adminCompanyMarketingRel);
    }
}