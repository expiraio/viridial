package com.viridial.sass.organization.forms;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.viridial.sass.common.forms.BaseForm;

public class OrganizationForm extends BaseForm {

    private String internalCode;
    private String externalCode;
    private String thumbnail;
    private String name;
    private String description;
    private String skills;

    private String statusInternalCode;
    private String statusLabel;
    private Long statusId;

    private OffsetDateTime statust;

    private String typeInternalCode;
    private String typeLabel;
    private Long typeId;

    private String departmentInternalCode;
    private String departmentLabel;
    private Long departmentId;

    /*
     * =========================
     * ORGANIZATION HIERARCHY
     * =========================
     */
    private String parentInternalCode;

    private String parentName;

    private Long parentId;

    private Set<OrganizationForm> children = new HashSet<>();

    /**
     * Root = 0, child = parent.level + 1
     */
    private int level;

    /**
     * Example: /1/3/8/
     * Fast subtree queries
     */
    private String path;

    public String getInternalCode() {
        return internalCode;
    }

    public void setInternalCode(String internalCode) {
        this.internalCode = internalCode;
    }

    public String getExternalCode() {
        return externalCode;
    }

    public void setExternalCode(String externalCode) {
        this.externalCode = externalCode;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public String getStatusInternalCode() {
        return statusInternalCode;
    }

    public void setStatusInternalCode(String statusInternalCode) {
        this.statusInternalCode = statusInternalCode;
    }

    public String getStatusLabel() {
        return statusLabel;
    }

    public void setStatusLabel(String statusLabel) {
        this.statusLabel = statusLabel;
    }

    public Long getStatusId() {
        return statusId;
    }

    public void setStatusId(Long statusId) {
        this.statusId = statusId;
    }

    public OffsetDateTime getStatust() {
        return statust;
    }

    public void setStatust(OffsetDateTime statust) {
        this.statust = statust;
    }

    public String getTypeInternalCode() {
        return typeInternalCode;
    }

    public void setTypeInternalCode(String typeInternalCode) {
        this.typeInternalCode = typeInternalCode;
    }

    public String getTypeLabel() {
        return typeLabel;
    }

    public void setTypeLabel(String typeLabel) {
        this.typeLabel = typeLabel;
    }

    public Long getTypeId() {
        return typeId;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    public String getDepartmentInternalCode() {
        return departmentInternalCode;
    }

    public void setDepartmentInternalCode(String departmentInternalCode) {
        this.departmentInternalCode = departmentInternalCode;
    }

    public String getDepartmentLabel() {
        return departmentLabel;
    }

    public void setDepartmentLabel(String departmentLabel) {
        this.departmentLabel = departmentLabel;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public String getParentInternalCode() {
        return parentInternalCode;
    }

    public void setParentInternalCode(String parentInternalCode) {
        this.parentInternalCode = parentInternalCode;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public Set<OrganizationForm> getChildren() {
        return children;
    }

    public void setChildren(Set<OrganizationForm> children) {
        this.children = children;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("OrganizationForm{");
        sb.append("internalCode=").append(internalCode);
        sb.append(", externalCode=").append(externalCode);
        sb.append(", externalCode=").append(name);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((internalCode == null) ? 0 : internalCode.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OrganizationForm other = (OrganizationForm) obj;
        if (internalCode == null) {
            if (other.internalCode != null)
                return false;
        } else if (!internalCode.equals(other.internalCode))
            return false;
        return true;
    }
}
