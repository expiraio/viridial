package com.viridial.sass.parameters.entities;

import com.viridial.sass.common.entities.BaseEntity;
import com.viridial.sass.organization.entities.TenantEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

@Entity
@Table(name = "conf_countries", indexes = {
        @Index(name = "idx_country_iso2", columnList = "iso2"),
        @Index(name = "idx_country_iso3", columnList = "iso3"),
        @Index(name = "idx_country_region", columnList = "region")
})
public class CountryEntity extends BaseEntity {

    @Column(name = "inter_code", unique = true, nullable = false)
    private String internalCode;
    @Column(name = "exter_code")
    private String externalCode;
    private String flag;
    private String iso2;
    private String iso3;
    @Column(name = "numeric_code")
    private String numericCode;
    private String name;
    @Column(name = "official_name")
    private String officialName;
    @Column(name = "phone_code")
    private String phoneCode;
    @Column(name = "currency_code")
    private String currencyCode;
    @Column(name = "region")
    private String region;
    @Column(name = "subregion")
    private String subregion;
    @Column(name = "emoji_flag")
    private String emojiFlag;
    private boolean enabled;

    public String getInternalCode() {
        return internalCode;
    }

    public void setInternalCode(String internalCode) {
        this.internalCode = internalCode;
    }

    public String getExternalCode() {
        return externalCode;
    }

    public void setExternalCode(String externalCode) {
        this.externalCode = externalCode;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getIso2() {
        return iso2;
    }

    public void setIso2(String iso2) {
        this.iso2 = iso2;
    }

    public String getIso3() {
        return iso3;
    }

    public void setIso3(String iso3) {
        this.iso3 = iso3;
    }

    public String getNumericCode() {
        return numericCode;
    }

    public void setNumericCode(String numericCode) {
        this.numericCode = numericCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOfficialName() {
        return officialName;
    }

    public void setOfficialName(String officialName) {
        this.officialName = officialName;
    }

    public String getPhoneCode() {
        return phoneCode;
    }

    public void setPhoneCode(String phoneCode) {
        this.phoneCode = phoneCode;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getSubregion() {
        return subregion;
    }

    public void setSubregion(String subregion) {
        this.subregion = subregion;
    }

    public String getEmojiFlag() {
        return emojiFlag;
    }

    public void setEmojiFlag(String emojiFlag) {
        this.emojiFlag = emojiFlag;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("CountryEntity{");
        sb.append("internalCode=").append(internalCode);
        sb.append(", externalCode=").append(externalCode);
        sb.append(", name=").append(name);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((internalCode == null) ? 0 : internalCode.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CountryEntity other = (CountryEntity) obj;
        if (internalCode == null) {
            if (other.internalCode != null)
                return false;
        } else if (!internalCode.equals(other.internalCode))
            return false;
        return true;
    }
}
