package com.viridial.sass.organization.entities;

import java.time.OffsetDateTime;

import com.viridial.sass.common.entities.BaseEntity;
import com.viridial.sass.parameters.entities.ParameterEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "org_org_user")
public class OrganizationUserEntity extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "org_fk", nullable = false, updatable = false, insertable = false)
    private OrganizationEntity organization;
    @Column(name = "org_fk")
    private Long organizationId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_fk", nullable = false, updatable = false, insertable = false)
    private UserEntity user;
    @Column(name = "user_fk")
    private Long userId;

    private boolean active;
    @Column(name = "active_at")
    private OffsetDateTime activeAt;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "relation_type_fk", nullable = false, updatable = false, insertable = false)
    private ParameterEntity relationType;
    @Column(name = "relation_type_fk")
    private Long relationTypeId;

    @Column(name = "start_at")
    private OffsetDateTime startAt;
    @Column(name = "end_at")
    private OffsetDateTime endAt;

    public OrganizationEntity getOrganization() {
        return organization;
    }

    public void setOrganization(OrganizationEntity organization) {
        this.organization = organization;
    }

    public Long getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Long organizationId) {
        this.organizationId = organizationId;
    }

    public UserEntity getUser() {
        return user;
    }

    public void setUser(UserEntity user) {
        this.user = user;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public OffsetDateTime getActiveAt() {
        return activeAt;
    }

    public void setActiveAt(OffsetDateTime activeAt) {
        this.activeAt = activeAt;
    }

    public ParameterEntity getRelationType() {
        return relationType;
    }

    public void setRelationType(ParameterEntity relationType) {
        this.relationType = relationType;
    }

    public Long getRelationTypeId() {
        return relationTypeId;
    }

    public void setRelationTypeId(Long relationTypeId) {
        this.relationTypeId = relationTypeId;
    }

    public OffsetDateTime getStartAt() {
        return startAt;
    }

    public void setStartAt(OffsetDateTime startAt) {
        this.startAt = startAt;
    }

    public OffsetDateTime getEndAt() {
        return endAt;
    }

    public void setEndAt(OffsetDateTime endAt) {
        this.endAt = endAt;
    }

}
