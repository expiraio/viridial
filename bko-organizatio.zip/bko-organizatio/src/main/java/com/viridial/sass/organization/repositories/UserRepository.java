package com.viridial.sass.organization.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.viridial.sass.organization.entities.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, Long> {

    Optional<UserEntity> findByInternalCodeAndTenantIdAndDeletedAtIsNull(String internalCode, Long tenantId);

    Optional<UserEntity> findByInternalCodeAndTenantId(String internalCode, Long tenantId);

    Optional<UserEntity> findByIdAndDeletedAtIsNull(Long id);

    Optional<UserEntity> findByEmailAndDeletedAtIsNull(String email);

}
