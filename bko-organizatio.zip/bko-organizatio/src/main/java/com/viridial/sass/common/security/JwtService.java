package com.viridial.sass.common.security;

import com.viridial.sass.organization.entities.OrganizationEntity;
import com.viridial.sass.organization.entities.UserEntity;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {
    private static final String SECRET = "very-secret-key-change-me-please";
    private static final long EXPIRATION = 1000 * 60 * 60; // 1h

    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8));
    }

    public String generateToken(UserEntity user, String tenantId) {
        return Jwts.builder()
                .setSubject(user.getEmail())
                // .claim("role", user.getRole())
                .claim("tenant_id", tenantId)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    public String generateToken(UserEntity user) {
        return Jwts.builder()
                .setSubject(user.getEmail())
                // .claim("role", user.getRole())
                .claim("tenant_id", user.getTenantId())
                .claim("organizations",
                        user.getOrganizations().stream()
                                .filter(e -> e.isActive())
                                .map(e -> e.getOrganizationId())
                                .collect(Collectors.toSet()))
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

}
