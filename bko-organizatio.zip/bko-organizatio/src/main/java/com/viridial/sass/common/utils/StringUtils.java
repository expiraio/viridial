package com.viridial.sass.common.utils;

public final class StringUtils {

    private StringUtils() {
    }

    public static String setEmpty(String value) {
        return value != null ? value : "";
    }

}
