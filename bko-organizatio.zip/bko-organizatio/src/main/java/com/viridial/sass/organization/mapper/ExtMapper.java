package com.viridial.sass.organization.mapper;

import com.viridial.sass.common.entities.IBaseEntity;
import com.viridial.sass.common.forms.IBaseForm;

public abstract class ExtMapper {

    protected void toForm(IBaseEntity entity, IBaseForm form) {
        form.setId(entity.getId());
        form.setTenantId(entity.getTenantId());
        form.setCreatedAt(entity.getCreatedAt());
        form.setCreatedBy(entity.getCreatedBy());
        form.setUpdatedAt(entity.getUpdatedAt());
        form.setUpdatedBy(entity.getUpdatedBy());
        form.setDeletedAt(entity.getDeletedAt());
        form.setDeletedBy(entity.getDeletedBy());
    }
}
