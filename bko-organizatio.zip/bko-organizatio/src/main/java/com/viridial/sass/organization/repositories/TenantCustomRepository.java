package com.viridial.sass.organization.repositories;

import java.time.OffsetDateTime;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.viridial.sass.common.context.TenantContext;
import com.viridial.sass.organization.entities.TenantEntity;
import com.viridial.sass.parameters.repositories.ParameterCustomRepository;

@Repository
public class TenantCustomRepository {
    private final TenantRepository tenantRepository;
    private final ParameterCustomRepository parameterCustomRepository;

    public TenantCustomRepository(TenantRepository tenantRepository,
            ParameterCustomRepository parameterCustomRepository) {
        this.tenantRepository = tenantRepository;
        this.parameterCustomRepository = parameterCustomRepository;
    }

    public Optional<TenantEntity> findById(Long id) {
        return tenantRepository.findById(id);
    }

    public Optional<TenantEntity> findByInternalCodeAndDeletedAtIsNull(String internalCode) {
        return tenantRepository.findByInternalCodeAndDeletedAtIsNull(internalCode);
    }

    public Optional<TenantEntity> findByIdAndDeletedAtIsNull(Long id) {
        return tenantRepository.findByIdAndDeletedAtIsNull(id);
    }

    public Optional<TenantEntity> findByInternalCode(String internalCode) {
        return tenantRepository.findByInternalCode(internalCode);
    }

    public TenantEntity save(TenantEntity entity) {
        String code = parameterCustomRepository.generateInternalCode("TENANT_ENTITY_SEQ", entity.getName());
        entity.setInternalCode(code);
        return tenantRepository.save(entity);
    }

    public TenantEntity update(TenantEntity entity) {
        return tenantRepository.save(entity);
    }

    public void delete(TenantEntity entity) {
        entity.setDeletedAt(OffsetDateTime.now());
        entity.setDeletedBy(TenantContext.get().getUserId());
        tenantRepository.save(entity);
    }
}
