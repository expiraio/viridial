package com.viridial.sass.parameters.repositories;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.viridial.sass.common.context.TenantContext;
import com.viridial.sass.parameters.entities.CountryEntity;

@Repository
public class CountryCustomRepository {
    private final CountryRepository countryRepository;

    public CountryCustomRepository(CountryRepository countryRepository) {
        this.countryRepository = countryRepository;
    }

    public List<CountryEntity> findAll() {
        return countryRepository.findAll();
    }

    public List<CountryEntity> findByEnabledTrue() {
        return countryRepository.findByEnabledTrue();
    }

    public Optional<CountryEntity> findByIso2(String iso2) {
        return countryRepository.findByIso2(iso2);
    }

    public Optional<CountryEntity> findByIso2AndEnabledTrue(String iso2) {
        return countryRepository.findByIso2AndEnabledTrue(iso2);
    }

    public Optional<CountryEntity> findByIso3(String iso3) {
        return countryRepository.findByIso3(iso3);
    }

    public Optional<CountryEntity> findByIso3AndEnabledTrue(String iso3) {
        return countryRepository.findByIso3AndEnabledTrue(iso3);
    }

    public Optional<CountryEntity> findByNumericCode(String numericCode) {
        return countryRepository.findByNumericCode(numericCode);
    }

    public Optional<CountryEntity> findByNumericCodeAndEnabledTrue(String numericCode) {
        return countryRepository.findByNumericCodeAndEnabledTrue(numericCode);
    }

    public CountryEntity save(CountryEntity entity) {
        return countryRepository.save(entity);
    }

    public CountryEntity update(CountryEntity entity) {
        return countryRepository.save(entity);
    }

    public void delete(CountryEntity entity) {
        entity.setDeletedAt(OffsetDateTime.now());
        entity.setDeletedBy(TenantContext.get().getUserId());
        countryRepository.save(entity);
    }
}
