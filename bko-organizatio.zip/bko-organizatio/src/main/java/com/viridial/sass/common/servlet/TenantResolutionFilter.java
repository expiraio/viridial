package com.viridial.sass.common.servlet;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.filter.OncePerRequestFilter;

import com.viridial.sass.common.context.Tenant;
import com.viridial.sass.common.context.TenantContext;
import com.viridial.sass.organization.entities.TenantEntity;
import com.viridial.sass.organization.mapper.TenantMapper;
import com.viridial.sass.organization.repositories.TenantRepository;

import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class TenantResolutionFilter extends OncePerRequestFilter {

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getServletPath();

        return path.equals("/api/login")
                || path.equals("/api/signup")
                || path.startsWith("/api/auth/");
    }

    private final TenantRepository tenantRepository;
    private final TenantMapper tenantMapper;

    public TenantResolutionFilter(TenantRepository tenantRepository, TenantMapper tenantMapper) {
        this.tenantRepository = tenantRepository;
        this.tenantMapper = tenantMapper;
    }

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws java.io.IOException, jakarta.servlet.ServletException {

        try {
            Long tenantId = resolveTenant().getId();

            if (tenantId != null) {
                TenantEntity tenantEntity = tenantRepository
                        .findById(tenantId)
                        .orElseThrow(() -> new IllegalStateException("Tenant not found: " + tenantId));
                Tenant tenant = tenantMapper.toTenant(tenantEntity);
                TenantContext.set(tenant);
            }

            filterChain.doFilter(request, response);

        } finally {
            TenantContext.clear();
        }
    }

    private Tenant resolveTenant() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() instanceof Jwt jwt) {
            Long tenantId = jwt.getClaim("tenant_id");
            if (tenantId != null) {
                Tenant tenant = new Tenant();
                tenant.setId(tenantId);
                return tenant;
            }
        }

        return null;
    }

    private String resolveTenantCode(HttpServletRequest request) {
        // 1️⃣ Header-based
        String header = request.getHeader("X-Tenant-ID");
        if (header != null && !header.isBlank()) {
            return header;
        }

        // 2️⃣ Subdomain-based (optional)
        // acme.app.com → acme
        String host = request.getServerName();
        if (host != null && host.contains(".")) {
            return host.split("\\.")[0];
        }

        return null;
    }
}
