package com.viridial.sass.organization.mapper;

import org.springframework.stereotype.Component;

import com.viridial.sass.common.context.Tenant;
import com.viridial.sass.organization.entities.TenantEntity;
import com.viridial.sass.organization.forms.TenantForm;

@Component
public class TenantMapper extends ExtMapper {

    public Tenant toTenant(TenantEntity entity) {
        Tenant form = new Tenant();
        form.setId(entity.getId());
        form.setActive(entity.isActive());
        form.setInternalCode(entity.getInternalCode());
        form.setExternalCode(entity.getExternalCode());
        form.setName(entity.getName());
        form.setDescription(entity.getDescription());
        form.setSkills(entity.getSkills());
        form.setActive(entity.isActive());
        form.setActiveAt(entity.getActiveAt());
        return form;
    }

    public TenantForm toForm(TenantEntity entity) {
        TenantForm form = new TenantForm();
        super.toForm(entity, form);
        form.setId(entity.getId());
        form.setActive(entity.isActive());
        form.setInternalCode(entity.getInternalCode());
        form.setExternalCode(entity.getExternalCode());
        form.setName(entity.getName());
        form.setDescription(entity.getDescription());
        form.setSkills(entity.getSkills());
        form.setActive(entity.isActive());
        form.setActiveAt(entity.getActiveAt());
        return form;
    }
}
