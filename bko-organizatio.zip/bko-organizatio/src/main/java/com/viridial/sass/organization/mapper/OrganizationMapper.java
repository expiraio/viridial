package com.viridial.sass.organization.mapper;

import java.util.List;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.viridial.sass.organization.entities.OrganizationEntity;
import com.viridial.sass.organization.forms.OrganizationForm;

@Component
public class OrganizationMapper extends ExtMapper {

    public OrganizationForm toForm(OrganizationEntity entity) {
        OrganizationForm form = new OrganizationForm();
        super.toForm(entity, form);
        form.setId(entity.getId());
        form.setStatusId(entity.getStatusId());
        form.setInternalCode(entity.getInternalCode());
        form.setExternalCode(entity.getExternalCode());
        form.setName(entity.getName());
        form.setDescription(entity.getDescription());
        form.setSkills(entity.getSkills());
        form.setChildren(toForm(entity.getChildren()));
        form.setPath(entity.getPath());
        form.setLevel(entity.getLevel());

        if (entity.getDepartment() != null) {
            form.setDepartmentId(entity.getDepartmentId());
            form.setDepartmentLabel(entity.getDepartment().getLabel());
            form.setDepartmentInternalCode(entity.getDepartment().getInternalCode());
        }

        if (entity.getStatus() != null) {
            form.setStatusId(entity.getStatusId());
            form.setStatusLabel(entity.getStatus().getLabel());
            form.setParentInternalCode(entity.getStatus().getInternalCode());
        }
        if (entity.getType() != null) {
            form.setTypeId(entity.getTypeId());
            form.setTypeLabel(entity.getType().getLabel());
            form.setParentInternalCode(entity.getType().getInternalCode());
        }
        if (entity.getParent() != null) {
            form.setParentId(entity.getParentId());
            form.setParentName(entity.getParent().getName());
            form.setParentInternalCode(entity.getParent().getInternalCode());
        }
        return form;
    }

    public List<OrganizationForm> toForm(List<OrganizationEntity> list) {
        return list.stream().map(entity -> toForm(entity)).collect(Collectors.toList());
    }

    public Set<OrganizationForm> toForm(Set<OrganizationEntity> list) {
        return list.stream().map(entity -> toForm(entity)).collect(Collectors.toSet());
    }

}
