package com.viridial.sass.parameters.repositories;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.viridial.sass.common.context.TenantContext;
import com.viridial.sass.common.utils.SlugUtils;
import com.viridial.sass.parameters.entities.ParameterEntity;

@Repository
public class ParameterCustomRepository {
    private final ParameterRepository parameteRepository;

    public ParameterCustomRepository(ParameterRepository parameteRepository) {
        this.parameteRepository = parameteRepository;
    }

    public Long generateInternalCode(String internalCode) {
        ParameterEntity entity = parameteRepository
                .findByInternalCode(internalCode)
                .orElseThrow(() -> new IllegalStateException("InternalCode not found: " + internalCode));
        Long intCode = entity.getIntValue();
        entity.setIntValue(intCode + 1);
        parameteRepository.save(entity);
        return intCode;
    }

    public String generateInternalCode(String internalCode, String slug) {

        ParameterEntity entity = parameteRepository
                .findByInternalCode(internalCode)
                .orElseGet(() -> {
                    ParameterEntity e = new ParameterEntity();
                    e.setInternalCode(internalCode);
                    e.setIntValue(1L);
                    e.setLabel(slug);
                    e.setDescription(slug);
                    return e;
                });

        Long currentValue = entity.getIntValue();
        entity.setIntValue(currentValue + 1);

        parameteRepository.save(entity);

        return SlugUtils.toSlug(slug) + "-" + currentValue;
    }

    public List<ParameterEntity> findAll() {
        return parameteRepository.findAll();
    }

    public List<ParameterEntity> findByActiveTrue() {
        return parameteRepository.findByActiveTrue();
    }

    public List<ParameterEntity> findByTypeIdAndActiveTrue(Long typeId) {
        return parameteRepository.findByTypeIdAndActiveTrue(typeId);
    }

    public List<ParameterEntity> findByTypeId(Long typeId) {
        return parameteRepository.findByTypeId(typeId);
    }

    public Optional<ParameterEntity> findByInternalCodeAndActiveTrue(String internalCode) {
        return parameteRepository.findByInternalCodeAndActiveTrue(internalCode);
    }

    public Optional<ParameterEntity> findByInternalCode(String internalCode) {
        return parameteRepository.findByInternalCode(internalCode);
    }

    public ParameterEntity save(ParameterEntity entity) {
        String code = generateInternalCode("PARAMETER_ENTITY_SEQ", entity.getLabel());
        entity.setInternalCode(code);
        if (entity.getEndAt() != null) {
            entity.setEndAt(LocalDate.of(9000, 1, 1));
        }
        return parameteRepository.save(entity);
    }

    public ParameterEntity update(ParameterEntity entity) {
        return parameteRepository.save(entity);
    }

    public void delete(ParameterEntity entity) {
        entity.setDeletedAt(OffsetDateTime.now());
        entity.setDeletedBy(TenantContext.get().getUserId());
        parameteRepository.save(entity);
    }
}
