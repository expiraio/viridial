package com.viridial.sass.parameters.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.viridial.sass.parameters.entities.TimeZoneEntity;

public interface TimeZoneRepository extends JpaRepository<TimeZoneEntity, Long> {

    Optional<TimeZoneEntity> findByZoneId(String zoneId);

    List<TimeZoneEntity> findByCountryIso2(String countryIso2);

    List<TimeZoneEntity> findByEnabledTrue();
}