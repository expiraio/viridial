package com.viridial.sass.common.utils;

import java.text.Normalizer;
import java.util.Locale;

public final class SlugUtils {
    private static final int MAX_LENGTH = 100;

    private SlugUtils() {
    }

    public static String toSlug(String input) {
        if (input == null || input.isBlank()) {
            return "";
        }

        String slug = Normalizer.normalize(input, Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "") // remove accents
                .toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", "-") // non-alphanum → dash
                .replaceAll("(^-|-$)", ""); // trim dashes
        return slug.length() > MAX_LENGTH ? slug.substring(0, MAX_LENGTH) : slug;
    }
}
