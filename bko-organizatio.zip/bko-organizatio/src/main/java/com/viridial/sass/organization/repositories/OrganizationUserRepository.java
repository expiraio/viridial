package com.viridial.sass.organization.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.viridial.sass.organization.entities.OrganizationUserEntity;

public interface OrganizationUserRepository extends JpaRepository<OrganizationUserEntity, Long> {

    Optional<OrganizationUserEntity> findByUserIdAndTenantIdAndDeletedAtIsNull(Long userId, Long tenantId);

    Optional<OrganizationUserEntity> findByOrganizationIdAndTenantIdAndDeletedAtIsNull(Long userId, Long tenantId);

    Optional<OrganizationUserEntity> findByIdAndDeletedAtIsNull(Long id);
}
