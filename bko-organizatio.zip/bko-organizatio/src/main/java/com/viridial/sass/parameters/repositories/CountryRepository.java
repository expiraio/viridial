package com.viridial.sass.parameters.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.viridial.sass.parameters.entities.CountryEntity;

public interface CountryRepository extends JpaRepository<CountryEntity, Long> {

    List<CountryEntity> findByEnabledTrue();

    Optional<CountryEntity> findByIso2(String iso2);

    Optional<CountryEntity> findByIso2AndEnabledTrue(String iso2);

    Optional<CountryEntity> findByIso3(String iso3);

    Optional<CountryEntity> findByIso3AndEnabledTrue(String iso3);

    Optional<CountryEntity> findByNumericCode(String numericCode);

    Optional<CountryEntity> findByNumericCodeAndEnabledTrue(String numericCode);
}
