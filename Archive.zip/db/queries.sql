-- db/queries.sql
-- Query to identify beneficiaries eligible for anonymization.
-- Parameters to vary: interval years (default 6), recent months (default 6)

-- Example (static): find beneficiaries whose last event is older than 6 years and not created in last 6 months
WITH last_dates AS (
  SELECT b.id,
    (SELECT max(v.date_versement) FROM versement v WHERE v.id_beneficiaire = b.id) AS last_versement,
    (SELECT max(r.date_regularisation) FROM regularisation_versement r JOIN versement v2 ON r.id_versement = v2.id WHERE v2.id_beneficiaire = b.id) AS last_regularisation,
    b.date_creation
  FROM beneficiaire b
)
SELECT b.id, b.nir, b.nom_famille, GREATEST(COALESCE(ld.last_versement,'1970-01-01'), COALESCE(ld.last_regularisation,'1970-01-01')) AS last_event_date
FROM beneficiaire b
JOIN last_dates ld ON ld.id = b.id
WHERE GREATEST(COALESCE(ld.last_versement,'1970-01-01'), COALESCE(ld.last_regularisation,'1970-01-01')) <= now() - INTERVAL '6 years'
  AND (b.date_creation IS NULL OR b.date_creation <= now() - INTERVAL '6 months')
  AND NOT EXISTS (
    SELECT 1 FROM regularisation_versement r2 JOIN versement v3 ON r2.id_versement = v3.id
    WHERE v3.id_beneficiaire = b.id
      AND r2.statut IN ('CREE','DECALE','BROUILLON','KO_BENEF','KO_TAUX')
  );

-- Note: adjust intervals and add checks against `versement.statut` if your schema includes it.
