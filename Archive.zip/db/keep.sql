-- keep.sql: backup of original sample data (preserved copy)
-- This file preserves the earlier combined DDL+INSERTs before we split schema/data.

-- (Excerpt - kept for reference)
-- INSERT INTO beneficiaire (id, nir, nom_famille, prenoms, adresse, code_postal, date_creation) VALUES
--  (44048, '1520144120004', 'DURET', 'JEAN', 'LA BREHANNERIE', '44640', '2019-03-01 05:00:23'),
--  (46138, '2550686194086', 'FAIVRE', 'MICHELLE', '22 QUAI LEON SECHER', '44400', '2019-05-03 05:00:36'),
--  (272118, '2571207019572', 'NANTA', 'MARIAMNE', '16 ROUTE DE SAINT-PAUL', '26200', '2018-10-30 05:00:17');

-- Full original content is available in repository history; this file is a lightweight pointer copy.
