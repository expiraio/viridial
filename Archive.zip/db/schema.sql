-- schema.sql: PostgreSQL DDL for RGPD sample schema
-- Tables: beneficiaire, declaration, versement, regularisation_versement,
--         lien_regul_vers_declaration, lien_benef_declaration

-- Drop if exists (safe for re-run in dev)
DROP TABLE IF EXISTS lien_benef_declaration;
DROP TABLE IF EXISTS lien_regul_vers_declaration;
DROP TABLE IF EXISTS regularisation_versement;
DROP TABLE IF EXISTS versement;
DROP TABLE IF EXISTS declaration;
DROP TABLE IF EXISTS beneficiaire;

CREATE TABLE beneficiaire (
  id BIGINT PRIMARY KEY,
  nir VARCHAR(50),
  nom_famille VARCHAR(200),
  prenoms VARCHAR(200),
  adresse TEXT,
  code_postal VARCHAR(20),
  date_creation TIMESTAMP NULL,
  mission VARCHAR(200)
);

CREATE TABLE declaration (
  id BIGINT PRIMARY KEY,
  code_type_declaration VARCHAR(50),
  num_fraction INTEGER NULL,
  num_ordre INTEGER NULL,
  mois VARCHAR(20),
  date_envoi TIMESTAMP NULL,
  id_declaration_remp BIGINT NULL,
  code_entite VARCHAR(50),
  code_sa VARCHAR(50),
  id_flux VARCHAR(200),
  nom_fichier VARCHAR(500),
  statut VARCHAR(100),
  date_reception_bis TIMESTAMP NULL,
  montant_versement NUMERIC NULL
);

CREATE TABLE versement (
  id BIGINT PRIMARY KEY,
  id_versement_bo VARCHAR(100),
  id_beneficiaire BIGINT REFERENCES beneficiaire(id),
  date_versement TIMESTAMP NULL,
  date_debut TIMESTAMP NULL,
  date_fin TIMESTAMP NULL,
  nb_jours INTEGER NULL,
  taux VARCHAR(50),
  code_type_taux VARCHAR(50),
  id_crm VARCHAR(100),
  montant_rnf NUMERIC NULL,
  montant_pas NUMERIC NULL,
  montant_net_a_verser NUMERIC NULL,
  montant_prestation_brut NUMERIC NULL,
  code_situation_fiscale VARCHAR(50)
);

CREATE TABLE regularisation_versement (
  id BIGINT PRIMARY KEY,
  id_versement BIGINT REFERENCES versement(id),
  motif VARCHAR(200),
  date_regularisation TIMESTAMP NULL,
  date_comptable TIMESTAMP NULL,
  montant_rnf_regularisation NUMERIC NULL,
  montant_pas_regularisation NUMERIC NULL,
  statut VARCHAR(100)
);

CREATE TABLE lien_regul_vers_declaration (
  id SERIAL PRIMARY KEY,
  id_regularisation BIGINT REFERENCES regularisation_versement(id),
  id_declaration BIGINT REFERENCES declaration(id)
);

CREATE TABLE lien_benef_declaration (
  id SERIAL PRIMARY KEY,
  id_declaration BIGINT REFERENCES declaration(id),
  beneficiaire_id BIGINT REFERENCES beneficiaire(id)
);

-- Indexes (basic)
CREATE INDEX idx_versement_beneficiaire ON versement(id_beneficiaire);
CREATE INDEX idx_regul_versement_versement ON regularisation_versement(id_versement);
CREATE INDEX idx_lien_regul_declaration_decl ON lien_regul_vers_declaration(id_declaration);

-- End of schema.sql
