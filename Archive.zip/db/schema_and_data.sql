-- PostgreSQL schema and sample data (generated from provided CSVs)
-- Tables: beneficiaire, versement, regularisation_versement, declaration,
--         lien_regul_vers_declaration, lien_benef_declaration

-- DROP TABLES (safe for re-run during development)
DROP TABLE IF EXISTS lien_benef_declaration;
DROP TABLE IF EXISTS lien_regul_vers_declaration;
DROP TABLE IF EXISTS regularisation_versement;
DROP TABLE IF EXISTS versement;
DROP TABLE IF EXISTS declaration;
DROP TABLE IF EXISTS beneficiaire;

CREATE TABLE beneficiaire (
  id BIGINT PRIMARY KEY,
  nir VARCHAR(50),
  nom_famille VARCHAR(200),
  prenoms VARCHAR(200),
  adresse TEXT,
  code_postal VARCHAR(20)
);

CREATE TABLE declaration (
  id BIGINT PRIMARY KEY,
  code_type_declaration VARCHAR(50),
  mois VARCHAR(20),
  date_envoi TIMESTAMP NULL,
  montant_versement NUMERIC NULL
);

CREATE TABLE versement (
  id BIGINT PRIMARY KEY,
  id_versement_bo VARCHAR(100),
  id_beneficiaire BIGINT REFERENCES beneficiaire(id),
  date_versement TIMESTAMP NULL,
  montant_net_a_verser NUMERIC NULL
);

CREATE TABLE regularisation_versement (
  id BIGINT PRIMARY KEY,
  id_versement BIGINT REFERENCES versement(id),
  motif VARCHAR(200),
  date_regularisation TIMESTAMP NULL,
  montant_rnf_regularisation NUMERIC NULL
);

CREATE TABLE lien_regul_vers_declaration (
  id SERIAL PRIMARY KEY,
  id_regularisation BIGINT REFERENCES regularisation_versement(id),
  id_declaration BIGINT REFERENCES declaration(id)
);

CREATE TABLE lien_benef_declaration (
  id SERIAL PRIMARY KEY,
  id_declaration BIGINT REFERENCES declaration(id),
  beneficiaire_id BIGINT REFERENCES beneficiaire(id)
);

-- Sample INSERTS for `beneficiaire` extracted from provided CSV (échantillon)
INSERT INTO beneficiaire (id, nir, nom_famille, prenoms, adresse, code_postal) VALUES
 (44048, '1520144120004', 'DURET', 'JEAN', 'LA BREHANNERIE', '44640'),
 (46138, '2550686194086', 'FAIVRE', 'MICHELLE', '22 QUAI LEON SECHER', '44400'),
 (272118, '2571207019572', 'NANTA', 'MARIAMNE', '16 ROUTE DE SAINT-PAUL', '26200');

-- Sample INSERTS for `versement` (échantillon) - note: numeric decimals converted '.'
INSERT INTO versement (id, id_versement_bo, id_beneficiaire, date_versement, montant_net_a_verser) VALUES
 (23241, '61538', 44048, '2019-02-21 00:00:00', 28.03),
 (286665, '116099', 44048, '2019-04-25 00:00:00', 56.89),
 (310612, '144024', 44048, '2019-05-27 00:00:00', 56.89);

-- Sample INSERTS for `regularisation_versement` (échantillon)
INSERT INTO regularisation_versement (id, id_versement, motif, date_regularisation, montant_rnf_regularisation) VALUES
 (820, 18892, 'REGUL TAUX CSG', '2019-05-10 02:00:00', NULL),
 (829, 282425, 'REGUL TAUX CSG', '2019-05-10 02:00:00', NULL),
 (808, 18840, 'REGUL TAUX MEDIAN', '2019-05-10 02:00:00', NULL),
 (5366, 18882, 'réception tardive justificatifs', '2019-06-11 14:21:57', NULL);

-- Insert declarations from the provided DECLARATION.csv snippet (échantillon)
INSERT INTO declaration (id, code_type_declaration, mois, date_envoi, montant_versement) VALUES
 (473, '01', '05/2019', '2019-06-05 11:16:06', NULL),
 (525, '01', '06/2019', '2019-07-03 22:21:28', NULL),
 (665, '01', '07/2019', '2019-08-05 14:58:11', NULL),
 (1981, '01', '12/2020', '2021-01-06 11:24:49', 5309);

-- Lien regularisation -> declaration from provided CSV (full list as given)
INSERT INTO lien_regul_vers_declaration (id_regularisation, id_declaration) VALUES
 (808, 473),
 (829, 473),
 (820, 473),
 (5366, 525),
 (5367, 525),
 (9049, 665),
 (15102, 845),
 (15103, 845),
 (42477, 1981),
 (42478, 1981),
 (42476, 1981),
 (45364, 2398),
 (45525, 2338),
 (45567, 2338),
 (45387, 2338),
 (45239, 2398),
 (168590, 5652),
 (108060, 4670),
 (81681, 4390),
 (81960, 4387),
 (108137, 4692),
 (206553, 6452);

-- Lien beneficiaire -> declaration (sample from CSV relations)
INSERT INTO lien_benef_declaration (id_declaration, beneficiaire_id) VALUES
 (473, 44048),
 (473, 286665),
 (665, 272118);

-- Note: Ce fichier contient un échantillon d'inserts extraits des CSV fournis.
-- Pour une importation complète et précise, il est préférable d'utiliser un script
-- qui parse exactement chaque fichier CSV/INSERT d'origine et convertit correctement
-- les formats de date/numérique (virgule -> point), et importe les lignes restantes.
