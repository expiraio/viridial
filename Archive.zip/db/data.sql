-- data.sql: sample INSERTs for RGPD schema (use after executing schema.sql)

-- Inserts for `beneficiaire` (with date_creation)
INSERT INTO beneficiaire (id, nir, nom_famille, prenoms, adresse, code_postal, date_creation, mission) VALUES
 (44048, '1520144120004', 'DURET', 'JEAN', 'LA BREHANNERIE', '44640', '2019-03-01 05:00:23', 'MISSION_A'),
 (46138, '2550686194086', 'FAIVRE', 'MICHELLE', '22 QUAI LEON SECHER', '44400', '2019-05-03 05:00:36', 'MISSION_B'),
 (272118, '2571207019572', 'NANTA', 'MARIAMNE', '16 ROUTE DE SAINT-PAUL', '26200', '2018-10-30 05:00:17', 'MISSION_C');

-- Inserts for `versement` (sample)
INSERT INTO versement (id, id_versement_bo, id_beneficiaire, date_versement, date_debut, date_fin, nb_jours, taux, code_type_taux, id_crm, montant_rnf, montant_pas, montant_net_a_verser, montant_prestation_brut, code_situation_fiscale) VALUES
 (23241, '61538', 44048, '2019-02-21 00:00:00', '2019-01-21 00:00:00', '2019-02-20 00:00:00', 1, '7,3', '01', '49643054', 31.26, 2.28, 28.03, 33.5, NULL),
 (286665, '116099', 44048, '2019-04-25 00:00:00', '2019-03-21 00:00:00', '2019-04-20 00:00:00', 1, '7,3', '01', '57935137', 63.46, 4.63, 56.89, 68, NULL),
 (310612, '144024', 44048, '2019-05-27 00:00:00', '2019-04-01 00:00:00', '2019-05-20 00:00:00', 1, '7,3', '01', '62066180', 63.46, 4.63, 56.89, 68, NULL);

-- Inserts for `regularisation_versement` (sample)
INSERT INTO regularisation_versement (id, id_versement, motif, date_regularisation, date_comptable, montant_rnf_regularisation, montant_pas_regularisation, statut) VALUES
 (820, 18892, 'REGUL TAUX CSG', '2019-05-10 02:00:00', '2019-05-14 02:00:00', NULL, NULL, 'ENVOYEE_DGFIP'),
 (829, 282425, 'REGUL TAUX CSG', '2019-05-10 02:00:00', '2019-05-14 02:00:00', NULL, NULL, 'ENVOYEE_DGFIP'),
 (808, 18840, 'REGUL TAUX MEDIAN', '2019-05-10 02:00:00', '2019-05-14 02:00:00', NULL, NULL, 'ENVOYEE_DGFIP');

-- Inserts for `declaration` (sample)
INSERT INTO declaration (id, code_type_declaration, num_fraction, num_ordre, mois, date_envoi, id_declaration_remp, code_entite, code_sa, id_flux, nom_fichier, statut, date_reception_bis, montant_versement) VALUES
 (473, '01', 10, 0, '05/2019', '2019-06-05 11:16:06', 603000000, NULL, 'GRA', 'RS', '10b386e57343f80b91aa23', 'OK', '2019-06-07 05:05:41', NULL),
 (525, '01', 10, 0, '06/2019', '2019-07-03 22:21:28', 382000000, NULL, 'GRA', 'RS', '10b38c3701da18dc6e672d', 'ANNULE', NULL, NULL),
 (665, '01', 10, 0, '07/2019', '2019-08-05 14:58:11', 917000000, NULL, 'GRA', 'RS', '10b391bd7b84ae2799ff55', 'OK', '2019-08-06 05:04:40', NULL);

-- Inserts for `lien_regul_vers_declaration` (full list provided earlier)
INSERT INTO lien_regul_vers_declaration (id_regularisation, id_declaration) VALUES
 (808, 473), (829, 473), (820, 473), (5366, 525), (5367, 525), (9049, 665), (15102, 845), (15103, 845), (42477, 1981), (42478, 1981), (42476, 1981), (45364, 2398), (45525, 2338), (45567, 2338), (45387, 2338), (45239, 2398), (168590, 5652), (108060, 4670), (81681, 4390), (81960, 4387), (108137, 4692), (206553, 6452);

-- Inserts for `lien_benef_declaration` (sample)
INSERT INTO lien_benef_declaration (id_declaration, beneficiaire_id) VALUES
 (473, 44048), (665, 272118);
-- data.sql: PostgreSQL initialization script (DDL + INSERTS)
-- Creates tables and inserts sample data including `date_creation` for beneficiaire

DROP TABLE IF EXISTS lien_benef_declaration;
DROP TABLE IF EXISTS lien_regul_vers_declaration;
DROP TABLE IF EXISTS regularisation_versement;
DROP TABLE IF EXISTS versement;
DROP TABLE IF EXISTS declaration;
DROP TABLE IF EXISTS beneficiaire;

CREATE TABLE beneficiaire (
  id BIGINT PRIMARY KEY,
  nir VARCHAR(50),
  nom_famille VARCHAR(200),
  prenoms VARCHAR(200),
  adresse TEXT,
  code_postal VARCHAR(20),
  date_creation TIMESTAMP NULL
);

CREATE TABLE declaration (
  id BIGINT PRIMARY KEY,
  code_type_declaration VARCHAR(50),
  mois VARCHAR(20),
  date_envoi TIMESTAMP NULL,
  montant_versement NUMERIC NULL
);

CREATE TABLE versement (
  id BIGINT PRIMARY KEY,
  id_versement_bo VARCHAR(100),
  id_beneficiaire BIGINT REFERENCES beneficiaire(id),
  date_versement TIMESTAMP NULL,
  montant_net_a_verser NUMERIC NULL
);

CREATE TABLE regularisation_versement (
  id BIGINT PRIMARY KEY,
  id_versement BIGINT REFERENCES versement(id),
  motif VARCHAR(200),
  date_regularisation TIMESTAMP NULL,
  montant_rnf_regularisation NUMERIC NULL
);

CREATE TABLE lien_regul_vers_declaration (
  id SERIAL PRIMARY KEY,
  id_regularisation BIGINT REFERENCES regularisation_versement(id),
  id_declaration BIGINT REFERENCES declaration(id)
);

CREATE TABLE lien_benef_declaration (
  id SERIAL PRIMARY KEY,
  id_declaration BIGINT REFERENCES declaration(id),
  beneficiaire_id BIGINT REFERENCES beneficiaire(id)
);

-- Inserts for beneficiaire including date_creation
INSERT INTO beneficiaire (id, nir, nom_famille, prenoms, adresse, code_postal, date_creation) VALUES
 (44048, '1520144120004', 'DURET', 'JEAN', 'LA BREHANNERIE', '44640', '2019-03-01 05:00:23'),
 (46138, '2550686194086', 'FAIVRE', 'MICHELLE', '22 QUAI LEON SECHER', '44400', '2019-05-03 05:00:36'),
 (272118, '2571207019572', 'NANTA', 'MARIAMNE', '16 ROUTE DE SAINT-PAUL', '26200', '2018-10-30 05:00:17');

-- Sample versement inserts (id_beneficiaire refers to above ids)
INSERT INTO versement (id, id_versement_bo, id_beneficiaire, date_versement, montant_net_a_verser) VALUES
 (23241, '61538', 44048, '2019-02-21 00:00:00', 28.03),
 (286665, '116099', 44048, '2019-04-25 00:00:00', 56.89),
 (310612, '144024', 44048, '2019-05-27 00:00:00', 56.89);

-- Sample regularisation_versement
INSERT INTO regularisation_versement (id, id_versement, motif, date_regularisation, montant_rnf_regularisation) VALUES
 (820, 18892, 'REGUL TAUX CSG', '2019-05-10 02:00:00', NULL),
 (829, 282425, 'REGUL TAUX CSG', '2019-05-10 02:00:00', NULL),
 (808, 18840, 'REGUL TAUX MEDIAN', '2019-05-10 02:00:00', NULL);

-- Sample declaration inserts
INSERT INTO declaration (id, code_type_declaration, mois, date_envoi, montant_versement) VALUES
 (473, '01', '05/2019', '2019-06-05 11:16:06', NULL),
 (525, '01', '06/2019', '2019-07-03 22:21:28', NULL),
 (665, '01', '07/2019', '2019-08-05 14:58:11', NULL);

-- Lien regularisation -> declaration
INSERT INTO lien_regul_vers_declaration (id_regularisation, id_declaration) VALUES
 (808, 473), (829, 473), (820, 473), (5366, 525), (5367, 525), (9049, 665);

-- Lien beneficiaire -> declaration (sample)
INSERT INTO lien_benef_declaration (id_declaration, beneficiaire_id) VALUES
 (473, 44048), (665, 272118);

-- End of data.sql
