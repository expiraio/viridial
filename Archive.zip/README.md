# Spring Batch Sample (Spring Boot 2.0.2.RELEASE)

Minimal sample project using Spring Boot 2.0.2.RELEASE and Java 1.8 with Spring Batch.

Try running:

```bash
mvn spring-boot:run
```

This will run a simple job that reads sample strings, upper-cases them and writes to stdout.

LES entities 
  beneficiaire  
  VERSEMENT -> beneficiaire.ID = VERSEMENT.beneficiaire_id
  REGULARISATION_VERSEMENT -> VERSEMENT.ID = REGULARISATION_VERSEMENT.ID_VERSEMENT
  LIEN_REGUL_VERS_DECLARATION -> REGULARISATION_VERSEMENT.ID = LIEN_REGUL_VERS_DECLARATION.ID_REGULARISATION
  LIEN_REGUL_VERS_DECLARATION -> DECLARATION.ID = LIEN_REGUL_VERS_DECLARATION.ID_DECLARATION
  DECLARATION -> REGULARISATION_VERSEMENT.DECLARATION = LIEN_REGUL_VERS_DECLARATION.ID_DECLARATION
  LIEN_BENEF_DECLARATION -> LIEN_BENEF_DECLARATION.ID_DECLARATION = DECLARATION.ID
  LIEN_BENEF_DECLARATION -> LIEN_BENEF_DECLARATION.beneficiaire_id = beneficiaire.ID

**RGPD — Batch d'anonymisation**

Objectif
- Anonymiser les données personnelles des bénéficiaires selon le RGPD.
- Délai par défaut : 6 ans après la dernière déclaration (versement ou régularisation). Paramétrable via `rgpd.anonymisation.delay-years`.

Règles principales
- Anonymiser uniquement les bénéficiaires dont la dernière action (versement ou régularisation) transmise à la DGFIP date d'au moins `rgpd.anonymisation.delay-years`.
- Exclusions :
  - bénéficiaires créés dans les `rgpd.exclusion.recent-months` derniers mois (par défaut 6),
  - bénéficiaires ayant au moins un versement ou une régularisation avec le statut dans {"CREE","DECALE","BROUILLON","KO_BENEF","KO_TAUX"}.

Champs à anonymiser (liste initiale)
- `beneficiaire.nir` -> NULL
- `beneficiaire.nom_famille`, `nom_usage`, `prenoms` -> 'Xxxxx'
- `beneficiaire.adresse`, `code_postal`, `localite`, `code_pays`, `code_distri_etr`, `compl_localisation`, `serv_distri` -> NULL
- `beneficiaire.date_naissance`, `lieu_naissance`, `ntt`, `departement_naissance`, `code_pays_naissance`, `code_sexe` -> NULL

Fichiers SQL
- `db/schema.sql` : DDL PostgreSQL (tables et index)
- `db/data.sql` : INSERTs d'exemple (échantillon)
- `db/queries.sql` : requêtes utiles (sélection des bénéficiaires éligibles)

Sélection des bénéficiaires éligibles — requête d'exemple
1. Charger `db/schema.sql` puis `db/data.sql` dans la base de dev.
2. Exécuter la requête suivante (paramètres : `years` = 6, `recent_months` = 6) :

```sql
WITH last_dates AS (
  SELECT b.id,
    (SELECT max(v.date_versement) FROM versement v WHERE v.id_beneficiaire = b.id) AS last_versement,
    (SELECT max(r.date_regularisation) FROM regularisation_versement r JOIN versement v2 ON r.id_versement = v2.id WHERE v2.id_beneficiaire = b.id) AS last_regularisation,
    b.date_creation
  FROM beneficiaire b
)
SELECT b.id, b.nir, b.nom_famille,
  GREATEST(COALESCE(ld.last_versement,'1970-01-01'), COALESCE(ld.last_regularisation,'1970-01-01')) AS last_event_date
FROM beneficiaire b
JOIN last_dates ld ON ld.id = b.id
WHERE GREATEST(COALESCE(ld.last_versement,'1970-01-01'), COALESCE(ld.last_regularisation,'1970-01-01')) <= now() - INTERVAL '6 years'
  AND (b.date_creation IS NULL OR b.date_creation <= now() - INTERVAL '6 months')
  AND NOT EXISTS (
    SELECT 1 FROM regularisation_versement r2 JOIN versement v3 ON r2.id_versement = v3.id
    WHERE v3.id_beneficiaire = b.id
      AND r2.statut IN ('CREE','DECALE','BROUILLON','KO_BENEF','KO_TAUX')
  );
```

Notes
- La requête exclut désormais les enregistrements dont le `statut` est dans ('CREE','DECALE','BROUILLON','KO_BENEF','KO_TAUX')
  présents soit dans `regularisation_versement` (via le lien vers `versement`), soit directement dans `versement`.
- Les intervalles (`6 years`, `6 months`) sont paramétrables via les propriétés Spring suivantes :
  - `rgpd.anonymisation.delay-years` (par défaut 6)
  - `rgpd.exclusion.recent-months` (par défaut 6)

Implémentation initiale
- Un service d'anonymisation et un runner ont été ajoutés (squelette) pour :
  1. Exécuter la requête de sélection des bénéficiaires éligibles,
  2. Parcourir les IDs par chunks,
  3. Anonymiser les champs listés et sauvegarder.

Prochaines étapes possibles
- Générer toutes les INSERTs depuis les CSV fournis automatiquement.
- Poursuivre l'implémentation Java du `Job` d'anonymisation (tests, audit, scheduling).

Commandes utiles

```bash
# Exécuter DDL
psql -h localhost -U rgpduser -d rgpddb -f db/schema.sql

# Charger données échantillon
psql -h localhost -U rgpduser -d rgpddb -f db/data.sql

# Lancer l'app (profil / propriété à ajuster)
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

Indiquez si vous voulez que je génère automatiquement les INSERTs complets depuis vos CSV, ou que je termine l'implémentation Java complète (job, tests, audit). 

**Testing scenarios and how to run them**

Below are concise scenarios and commands to validate the anonymisation job locally and at scale.

- Quick build and run (dev profile):

```bash
# build
mvn -DskipTests package

# run with the dev profile (adjust DB config in application-dev.properties)
java -jar target/*.jar --spring.profiles.active=dev
```

- Dry-run (non-destructive) — records intended changes to `rgpd_dry_runs` instead of updating `beneficiaire`:

1. Set `rgpd.dry-run=true` in `application-dev.properties` or pass on the command line.
2. Run the job (as above). Inspect `rgpd_dry_runs` to review planned anonymizations.

```bash
# example: override property on run
java -jar target/*.jar --spring.profiles.active=dev --rgpd.dry-run=true

# check planned updates
psql -h localhost -U rgpduser -d rgpddb -c "SELECT COUNT(*) FROM rgpd_dry_runs;"
psql -h localhost -U rgpduser -d rgpddb -c "SELECT * FROM rgpd_dry_runs LIMIT 10;"
```

- Full anonymisation run (destructive):

1. Ensure `rgpd.dry-run=false` (or omit the flag).
2. Tune `rgpd.chunk-size` and `rgpd.jdbc-fetch-size` according to your memory/DB capacity (defaults are conservative).
3. Run the job and monitor `rgpd_reports` and the CSV reports under `reports/`.

```bash
java -jar target/*.jar --spring.profiles.active=dev

# inspect report table
psql -h localhost -U rgpduser -d rgpddb -c "SELECT * FROM rgpd_reports ORDER BY id DESC LIMIT 5;"

# list generated CSVs
ls -al reports/ | tail -n 10
```

- Verify effectiveness (pre/post PII counts):

The job records counts before and after the anonymisation (pre/post counts are written to `rgpd_reports` and included in the CSV report). You can also run SQL checks manually:

```sql
-- Count non-null NIR before/after
SELECT COUNT(*) FROM beneficiaire WHERE nir IS NOT NULL;

-- Count beneficiaries with non-placeholder family name (replace 'Xxxxx' with your configured placeholder)
SELECT COUNT(*) FROM beneficiaire WHERE nom_famille IS NOT NULL AND nom_famille <> 'Xxxxx';

-- Confirm anonymization timestamps
SELECT COUNT(*) FROM beneficiaire WHERE date_anonymization IS NOT NULL;
```

- Scale and performance tips for millions of rows:

- Use `rgpd.jdbc-fetch-size` (default 1000) and increase `rgpd.chunk-size` to a value that balances throughput and memory (try 1000, 5000).
- Consider running the job on a machine close to the DB (network latency) and ensure DB autovacuum and WAL settings are tuned for large updates.
- Use `rgpd.dry-run=true` first to estimate numbers and runtime without destructive changes.

If you want, I can add a small `make test-run` target or example scripts to automate these scenarios.



