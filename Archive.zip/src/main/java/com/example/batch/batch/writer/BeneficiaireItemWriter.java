package com.example.batch.batch.writer;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.example.batch.config.RgpdProperties;
import com.example.batch.domain.Beneficiaire;

@Component
public class BeneficiaireItemWriter implements ItemWriter<Beneficiaire> {

    private final JdbcTemplate jdbc;
    private final RgpdProperties props;

    public BeneficiaireItemWriter(JdbcTemplate jdbc, RgpdProperties props) {
        this.jdbc = jdbc;
        this.props = props;
    }

    @Override
    public void write(List<? extends Beneficiaire> items) throws Exception {
        if (items == null || items.isEmpty()) return;
        String sqlBenef = "UPDATE beneficiaire SET nir = NULL, nom_famille = ?, prenoms = ?, adresse = NULL, code_postal = NULL, date_anonymization = ? WHERE id = ?";
        String sqlInd = "UPDATE individual SET nir = NULL, nom_famille = ?, prenoms = ?, adresse = NULL, code_postal = NULL, date_anonymization = ? WHERE id = ?";
        LocalDateTime now = LocalDateTime.now();
        Object[][] batchArgs = new Object[items.size()][];
        for (int i = 0; i < items.size(); i++) {
            Beneficiaire b = items.get(i);
            batchArgs[i] = new Object[] { props.getAnonymizedFamilyName(), props.getAnonymizedGivenName(), Timestamp.valueOf(now), b.getId() };
        }

        if (props.isDryRun()) {
            // record intended anonymizations in a dry-run table for review
            try {
                jdbc.execute("CREATE TABLE IF NOT EXISTS rgpd_dry_runs (id BIGINT PRIMARY KEY)");
            } catch (Exception e) {
                // ignore
            }
            String drySql = "INSERT INTO rgpd_dry_runs (id) VALUES (?) ON CONFLICT (id) DO NOTHING";
            Object[][] dryArgs = new Object[items.size()][];
            for (int i = 0; i < items.size(); i++) {
                Beneficiaire b = items.get(i);
                dryArgs[i] = new Object[] { b.getId() };
            }
            jdbc.batchUpdate(drySql, java.util.Arrays.asList(dryArgs));
        } else {
            // update beneficiaire
            jdbc.batchUpdate(sqlBenef, java.util.Arrays.asList(batchArgs));
            // update individual (if corresponding rows exist)
            jdbc.batchUpdate(sqlInd, java.util.Arrays.asList(batchArgs));
        }
    }
}
