package com.example.batch.batch.processor;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.example.batch.domain.Beneficiaire;
import com.example.batch.repository.BeneficiaireRepository;

@Component
public class BeneficiaireItemProcessor implements ItemProcessor<Long, Beneficiaire> {

    private final BeneficiaireRepository repo;

    public BeneficiaireItemProcessor(BeneficiaireRepository repo) {
        this.repo = repo;
    }

    @Override
    public Beneficiaire process(Long id) throws Exception {
        Optional<Beneficiaire> ob = repo.findById(id);
        if (!ob.isPresent()) return null;
        Beneficiaire b = ob.get();
        // anonymisation rules applied here
        b.setNir(null);
        b.setNomFamille("Xxxxx");
        b.setPrenoms("Xxxxx");
        b.setAdresse(null);
        b.setCodePostal(null);
        b.setDateAnonymization(LocalDateTime.now());
        return b;
    }
}
