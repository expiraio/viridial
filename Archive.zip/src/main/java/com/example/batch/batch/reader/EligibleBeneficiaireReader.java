package com.example.batch.batch.reader;

import java.sql.ResultSet;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.stereotype.Component;

import com.example.batch.config.RgpdProperties;

@Component
public class EligibleBeneficiaireReader implements ItemReader<Long>, ItemStream {

    private final DataSource dataSource;
    private final RgpdProperties props;
    private JdbcCursorItemReader<Long> delegate;

    public EligibleBeneficiaireReader(DataSource dataSource, RgpdProperties props) {
        this.dataSource = dataSource;
        this.props = props;
    }

    @PostConstruct
    public void init() {
        // Read IDs produced by the candidate selection steps (rgpd_candidates)
        String sql = "SELECT id FROM rgpd_candidates ORDER BY id";

        this.delegate = new JdbcCursorItemReaderBuilder<Long>()
            .name("eligibleBeneficiaireReader")
            .dataSource(dataSource)
            .sql(sql)
            .fetchSize(props.getJdbcFetchSize())
            .rowMapper((ResultSet rs, int rowNum) -> rs.getLong("id"))
            .build();
        try {
            this.delegate.afterPropertiesSet();
        } catch (Exception e) {
            throw new IllegalStateException("Failed to initialize delegate JdbcCursorItemReader", e);
        }
    }

    @Override
    public Long read() throws Exception {
        return delegate.read();
    }

    @Override
    public void open(ExecutionContext executionContext) {
        if (delegate instanceof ItemStream) {
            ((ItemStream) delegate).open(executionContext);
        }
    }

    @Override
    public void update(ExecutionContext executionContext) {
        if (delegate instanceof ItemStream) {
            ((ItemStream) delegate).update(executionContext);
        }
    }

    @Override
    public void close() {
        if (delegate instanceof ItemStream) {
            ((ItemStream) delegate).close();
        }
    }
}
