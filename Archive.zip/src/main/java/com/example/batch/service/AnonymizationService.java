package com.example.batch.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.example.batch.repository.BeneficiaireRepository;

@Service
public class AnonymizationService {

    private final JdbcTemplate jdbc;
    private final BeneficiaireRepository beneficiaireRepository;

    public AnonymizationService(JdbcTemplate jdbc, BeneficiaireRepository beneficiaireRepository) {
        this.jdbc = jdbc;
        this.beneficiaireRepository = beneficiaireRepository;
    }

    /**
     * Returns list of beneficiary IDs eligible for anonymization using the same logic as in db/queries.sql.
     * Note: years/months are concatenated into the INTERVAL literal; they must be integers.
     */
    public List<Long> findEligibleBeneficiaireIds(int years, int recentMonths) {
        String sql = "WITH last_dates AS ("
                + " SELECT b.id,"
                + " (SELECT max(v.date_versement) FROM versement v WHERE v.id_beneficiaire = b.id) AS last_versement,"
                + " (SELECT max(r.date_regularisation) FROM regularisation_versement r JOIN versement v2 ON r.id_versement = v2.id WHERE v2.id_beneficiaire = b.id) AS last_regularisation,"
                + " b.date_creation"
                + " FROM beneficiaire b)"
                + " SELECT id FROM last_dates WHERE GREATEST(COALESCE(last_versement,'1970-01-01'), COALESCE(last_regularisation,'1970-01-01')) <= now() - INTERVAL '" + years + " years'"
                + " AND (date_creation IS NULL OR date_creation <= now() - INTERVAL '" + recentMonths + " months')"
                + " AND NOT EXISTS (SELECT 1 FROM regularisation_versement r2 JOIN versement v3 ON r2.id_versement = v3.id WHERE v3.id_beneficiaire = last_dates.id AND r2.statut IN ('CREE','DECALE','BROUILLON','KO_BENEF','KO_TAUX'))";

        List<Long> ids = jdbc.queryForList(sql, Long.class);
        return ids == null ? new ArrayList<>() : ids;
    }


}
