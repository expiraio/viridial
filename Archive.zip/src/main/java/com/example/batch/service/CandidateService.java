package com.example.batch.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CandidateService {

    private final JdbcTemplate jdbc;

    public CandidateService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Transactional
    public void createCandidatesTable() {
        jdbc.execute("CREATE TABLE IF NOT EXISTS rgpd_candidates (id BIGINT PRIMARY KEY)");
        jdbc.execute("TRUNCATE TABLE rgpd_candidates");
    }

    @Transactional
    public void populateInitialCandidates() {
        // only include beneficiaries that have not yet been anonymized
        jdbc.update("INSERT INTO rgpd_candidates (id) SELECT id FROM beneficiaire WHERE id IS NOT NULL AND date_anonymization IS NULL ON CONFLICT (id) DO NOTHING");
    }

    @Transactional
    public void filterByLastEvent(int years) {
        String sql = "DELETE FROM rgpd_candidates c WHERE (\n"
                + "  (SELECT GREATEST(COALESCE(MAX(v.date_versement), '1970-01-01'::timestamp), COALESCE(MAX(r.date_regularisation), '1970-01-01'::timestamp))\n"
                + "   FROM versement v LEFT JOIN regularisation_versement r ON r.id_versement = v.id\n"
                + "   WHERE v.id_beneficiaire = c.id) > now() - INTERVAL '" + years + " years'\n"
                + ")";
        jdbc.execute(sql);
    }

    @Transactional
    public void filterByCreationRecentMonths(int months) {
        String sql = "DELETE FROM rgpd_candidates c WHERE exists (select 1 from beneficiaire b where b.id = c.id and b.date_creation IS NOT NULL and b.date_creation > now() - INTERVAL '" + months + " months')";
        jdbc.execute(sql);
    }

    @Transactional
    public void filterByStatuses() {
        String sql1 = "DELETE FROM rgpd_candidates c WHERE EXISTS (SELECT 1 FROM versement v WHERE v.id_beneficiaire = c.id AND v.statut IN ('CREE','DECALE','BROUILLON','KO_BENEF','KO_TAUX'))";
        String sql2 = "DELETE FROM rgpd_candidates c WHERE EXISTS (SELECT 1 FROM regularisation_versement r JOIN versement v ON r.id_versement = v.id WHERE v.id_beneficiaire = c.id AND r.statut IN ('CREE','DECALE','BROUILLON','KO_BENEF','KO_TAUX'))";
        jdbc.execute(sql1);
        jdbc.execute(sql2);
    }

}
