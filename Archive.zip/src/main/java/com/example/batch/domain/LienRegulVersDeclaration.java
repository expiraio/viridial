package com.example.batch.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "lien_regul_vers_declaration")
public class LienRegulVersDeclaration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "id_regularisation")
    private RegularisationVersement regularisation;

    @ManyToOne
    @JoinColumn(name = "id_declaration")
    private Declaration declaration;

    public LienRegulVersDeclaration() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public RegularisationVersement getRegularisation() { return regularisation; }
    public void setRegularisation(RegularisationVersement regularisation) { this.regularisation = regularisation; }
    public Declaration getDeclaration() { return declaration; }
    public void setDeclaration(Declaration declaration) { this.declaration = declaration; }
}
