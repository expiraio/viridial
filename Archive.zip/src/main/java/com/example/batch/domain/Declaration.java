package com.example.batch.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "declaration")
public class Declaration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "code_type_declaration")
    private String codeTypeDeclaration;

    @Column(name = "mois")
    private String mois;

    @Column(name = "date_envoi")
    private LocalDateTime dateEnvoi;

    @Column(name = "montant_versement")
    private Double montantVersement;

    public Declaration() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCodeTypeDeclaration() { return codeTypeDeclaration; }
    public void setCodeTypeDeclaration(String codeTypeDeclaration) { this.codeTypeDeclaration = codeTypeDeclaration; }
    public String getMois() { return mois; }
    public void setMois(String mois) { this.mois = mois; }
    public LocalDateTime getDateEnvoi() { return dateEnvoi; }
    public void setDateEnvoi(LocalDateTime dateEnvoi) { this.dateEnvoi = dateEnvoi; }
    public Double getMontantVersement() { return montantVersement; }
    public void setMontantVersement(Double montantVersement) { this.montantVersement = montantVersement; }
}
