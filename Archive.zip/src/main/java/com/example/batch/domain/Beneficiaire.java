package com.example.batch.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "beneficiaire")
public class Beneficiaire {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nir")
    private String nir;

    @Column(name = "nom_famille")
    private String nomFamille;

    @Column(name = "prenoms")
    private String prenoms;

    @Column(name = "adresse")
    private String adresse;

    @Column(name = "code_postal")
    private String codePostal;

    @Column(name = "date_creation")
    private LocalDateTime dateCreation;

    @Column(name = "mission")
    private String mission;

    @Column(name = "date_anonymization")
    private LocalDateTime dateAnonymization;

    public Beneficiaire() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNir() { return nir; }
    public void setNir(String nir) { this.nir = nir; }
    public String getNomFamille() { return nomFamille; }
    public void setNomFamille(String nomFamille) { this.nomFamille = nomFamille; }
    public String getPrenoms() { return prenoms; }
    public void setPrenoms(String prenoms) { this.prenoms = prenoms; }
    public String getAdresse() { return adresse; }
    public void setAdresse(String adresse) { this.adresse = adresse; }
    public String getCodePostal() { return codePostal; }
    public void setCodePostal(String codePostal) { this.codePostal = codePostal; }
    public LocalDateTime getDateCreation() { return dateCreation; }
    public void setDateCreation(LocalDateTime dateCreation) { this.dateCreation = dateCreation; }
    public String getMission() { return mission; }
    public void setMission(String mission) { this.mission = mission; }

    public LocalDateTime getDateAnonymization() {
        return dateAnonymization;
    }

    public void setDateAnonymization(LocalDateTime dateAnonymization) {
        this.dateAnonymization = dateAnonymization;
    }
    
}
