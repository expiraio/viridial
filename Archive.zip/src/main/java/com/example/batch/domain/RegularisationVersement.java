package com.example.batch.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "regularisation_versement")
public class RegularisationVersement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "id_versement")
    private Versement versement;

    @Column(name = "motif")
    private String motif;

    @Column(name = "date_regularisation")
    private LocalDateTime dateRegularisation;

    @Column(name = "montant_rnf_regularisation")
    private Double montantRnfRegularisation;

    public RegularisationVersement() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Versement getVersement() { return versement; }
    public void setVersement(Versement versement) { this.versement = versement; }
    public String getMotif() { return motif; }
    public void setMotif(String motif) { this.motif = motif; }
    public LocalDateTime getDateRegularisation() { return dateRegularisation; }
    public void setDateRegularisation(LocalDateTime dateRegularisation) { this.dateRegularisation = dateRegularisation; }
    public Double getMontantRnfRegularisation() { return montantRnfRegularisation; }
    public void setMontantRnfRegularisation(Double montantRnfRegularisation) { this.montantRnfRegularisation = montantRnfRegularisation; }
}
