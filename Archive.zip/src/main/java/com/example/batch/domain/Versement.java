package com.example.batch.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "versement")
public class Versement {

    public Versement() {}
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "beneficiaire_id")
    private Beneficiaire beneficiaire;

    @Column(name = "id_versement_bo")
    private String idVersementBo;

    @Column(name = "status")
    private String status;

    @Column(name = "date_versement")
    private LocalDateTime dateVersement;

    @Column(name = "montant_net_a_verser")
    private Double montantNetAVerser;

    public String getIdVersementBo() { return idVersementBo; }
    public void setIdVersementBo(String idVersementBo) { this.idVersementBo = idVersementBo; }
    public LocalDateTime getDateVersement() { return dateVersement; }
    public void setDateVersement(LocalDateTime dateVersement) { this.dateVersement = dateVersement; }
    public Double getMontantNetAVerser() { return montantNetAVerser; }
    public void setMontantNetAVerser(Double montantNetAVerser) { this.montantNetAVerser = montantNetAVerser; }
    

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Beneficiaire getBeneficiaire() { return beneficiaire; }
    public void setBeneficiaire(Beneficiaire beneficiaire) { this.beneficiaire = beneficiaire; }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    
}
