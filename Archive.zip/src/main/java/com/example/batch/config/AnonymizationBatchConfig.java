package com.example.batch.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.batch.domain.Beneficiaire;
import com.example.batch.listener.AnonymizationJobListener;
import com.example.batch.service.CandidateService;

@Configuration
public class AnonymizationBatchConfig {

    // Reader/Processor/Writer are provided as Spring components in separate classes

    @Bean
    public Step anonymizationStep(StepBuilderFactory steps, org.springframework.batch.item.ItemReader<Long> reader, org.springframework.batch.item.ItemProcessor<Long, Beneficiaire> processor, org.springframework.batch.item.ItemWriter<Beneficiaire> writer, RgpdProperties props) {
        return steps.get("anonymizationStep")
                .<Long, Beneficiaire>chunk(props.getChunkSize())
                .reader(reader)
                .processor(processor)
                .writer(writer)
                .build();
    }

    @Bean
    public Step createCandidatesStep(StepBuilderFactory steps, CandidateService candidateService) {
        Tasklet t = (contrib, ctx) -> {
            candidateService.createCandidatesTable();
            return RepeatStatus.FINISHED;
        };
        return steps.get("createCandidatesStep").tasklet(t).build();
    }

    @Bean
    public Step populateCandidatesStep(StepBuilderFactory steps, CandidateService candidateService) {
        Tasklet t = (contrib, ctx) -> {
            candidateService.populateInitialCandidates();
            return RepeatStatus.FINISHED;
        };
        return steps.get("populateCandidatesStep").tasklet(t).build();
    }

    @Bean
    public Step filterLastEventStep(StepBuilderFactory steps, CandidateService candidateService, RgpdProperties props) {
        Tasklet t = (contrib, ctx) -> {
            candidateService.filterByLastEvent(props.getAnonymisationDelayYears());
            return RepeatStatus.FINISHED;
        };
        return steps.get("filterLastEventStep").tasklet(t).build();
    }

    @Bean
    public Step filterCreationStep(StepBuilderFactory steps, CandidateService candidateService, RgpdProperties props) {
        Tasklet t = (contrib, ctx) -> {
            candidateService.filterByCreationRecentMonths(props.getExclusionRecentMonths());
            return RepeatStatus.FINISHED;
        };
        return steps.get("filterCreationStep").tasklet(t).build();
    }

    @Bean
    public Step filterStatusesStep(StepBuilderFactory steps, CandidateService candidateService) {
        Tasklet t = (contrib, ctx) -> {
            candidateService.filterByStatuses();
            return RepeatStatus.FINISHED;
        };
        return steps.get("filterStatusesStep").tasklet(t).build();
    }

    @Bean
    public Step verifyCandidatesStep(StepBuilderFactory steps, JdbcTemplate jdbc) {
        Logger log = LoggerFactory.getLogger(AnonymizationBatchConfig.class);
        Tasklet t = (contrib, ctx) -> {
            Integer count = jdbc.queryForObject("SELECT COUNT(*) FROM rgpd_candidates", Integer.class);
            ctx.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("rgpd.candidates.count", count);
            log.info("rgpd: candidate count = {}", count);
            return RepeatStatus.FINISHED;
        };
        return steps.get("verifyCandidatesStep").tasklet(t).build();
    }

    @Bean
            public Job anonymizationJob(JobBuilderFactory jobs,
                        Step createCandidatesStep,
                        Step populateCandidatesStep,
                        Step filterLastEventStep,
                        Step filterCreationStep,
                        Step filterStatusesStep,
                        Step verifyCandidatesStep,
                        Step anonymizationStep,
                        AnonymizationJobListener listener) {
            return jobs.get("anonymizationJob")
                .incrementer(new RunIdIncrementer())
                .start(createCandidatesStep)
                .next(populateCandidatesStep)
                .next(filterLastEventStep)
                .next(filterCreationStep)
                .next(filterStatusesStep)
                .next(verifyCandidatesStep)
                .next(anonymizationStep)
                .listener(listener)
                .build();
            }
}
