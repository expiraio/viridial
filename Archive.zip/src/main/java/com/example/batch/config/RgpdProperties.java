package com.example.batch.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "rgpd")
public class RgpdProperties {
    private int anonymisationDelayYears = 6;
    private int exclusionRecentMonths = 6;
    private int chunkSize = 100;
    private int jdbcFetchSize = 1000;
    private String anonymizedFamilyName = "Xxxxx";
    private String anonymizedGivenName = "Xxxxx";
    private boolean dryRun = false;
    private List<String> excludeStatuses = java.util.Arrays.asList("CREE","DECALE","BROUILLON","KO_BENEF","KO_TAUX");

    public int getAnonymisationDelayYears() { return anonymisationDelayYears; }
    public void setAnonymisationDelayYears(int anonymisationDelayYears) { this.anonymisationDelayYears = anonymisationDelayYears; }
    public int getExclusionRecentMonths() { return exclusionRecentMonths; }
    public void setExclusionRecentMonths(int exclusionRecentMonths) { this.exclusionRecentMonths = exclusionRecentMonths; }
    public int getChunkSize() { return chunkSize; }
    public void setChunkSize(int chunkSize) { this.chunkSize = chunkSize; }
    public int getJdbcFetchSize() { return jdbcFetchSize; }
    public void setJdbcFetchSize(int jdbcFetchSize) { this.jdbcFetchSize = jdbcFetchSize; }
    public String getAnonymizedFamilyName() { return anonymizedFamilyName; }
    public void setAnonymizedFamilyName(String anonymizedFamilyName) { this.anonymizedFamilyName = anonymizedFamilyName; }
    public String getAnonymizedGivenName() { return anonymizedGivenName; }
    public void setAnonymizedGivenName(String anonymizedGivenName) { this.anonymizedGivenName = anonymizedGivenName; }
    public List<String> getExcludeStatuses() { return excludeStatuses; }
    public void setExcludeStatuses(List<String> excludeStatuses) { this.excludeStatuses = excludeStatuses; }
    public boolean isDryRun() { return dryRun; }
    public void setDryRun(boolean dryRun) { this.dryRun = dryRun; }
}
