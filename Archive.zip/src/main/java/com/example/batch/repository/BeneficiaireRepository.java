package com.example.batch.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.batch.domain.Beneficiaire;

public interface BeneficiaireRepository extends JpaRepository<Beneficiaire, Long> {
}
