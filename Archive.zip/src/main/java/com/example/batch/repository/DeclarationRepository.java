package com.example.batch.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.batch.domain.Declaration;

public interface DeclarationRepository extends JpaRepository<Declaration, Long> {
}
