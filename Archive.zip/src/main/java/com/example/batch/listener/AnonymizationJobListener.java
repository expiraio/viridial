package com.example.batch.listener;

import java.io.File;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class AnonymizationJobListener implements JobExecutionListener {

    private final JdbcTemplate jdbc;

    public AnonymizationJobListener(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        // no-op
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        long readCount = 0L;
        long writeCount = 0L;
        for (StepExecution se : jobExecution.getStepExecutions()) {
            readCount += se.getReadCount();
            writeCount += se.getWriteCount();
        }

        Date start = jobExecution.getStartTime();
        Date end = jobExecution.getEndTime();
        String status = jobExecution.getStatus().toString();

        long anonymizedCount = 0L;
        try {
            if (start != null && end != null) {
                anonymizedCount = jdbc.queryForObject(
                        "SELECT COUNT(*) FROM beneficiaire WHERE date_anonymization >= ? AND date_anonymization <= ?",
                        new Object[] { start, end }, Long.class);
            } else {
                anonymizedCount = jdbc.queryForObject("SELECT COUNT(*) FROM beneficiaire WHERE date_anonymization IS NOT NULL", Long.class);
            }
        } catch (Exception e) {
            anonymizedCount = 0L;
        }

        // ensure reports directory
        File reportsDir = new File("reports");
        if (!reportsDir.exists()) reportsDir.mkdirs();

        String ts = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").withZone(ZoneId.systemDefault()).format(java.time.Instant.now());
        String filename = "reports/rgpd-report-" + ts + ".csv";
        try (java.io.FileWriter fw = new java.io.FileWriter(filename, false)) {
            fw.write("jobName,startTime,endTime,status,readCount,writeCount,anonymizedCount\n");
            fw.write(String.format("%s,%s,%s,%s,%d,%d,%d\n",
                    jobExecution.getJobInstance().getJobName(),
                    start == null ? "" : start,
                    end == null ? "" : end,
                    status,
                    readCount,
                    writeCount,
                    anonymizedCount));
        } catch (Exception e) {
            // ignore write errors
        }

        // persist summary in DB table
        try {
            jdbc.execute("CREATE TABLE IF NOT EXISTS rgpd_reports (id SERIAL PRIMARY KEY, job_name TEXT, start_time TIMESTAMP, end_time TIMESTAMP, status TEXT, read_count BIGINT, write_count BIGINT, anonymized_count BIGINT, report_path TEXT)");
            jdbc.update("INSERT INTO rgpd_reports (job_name,start_time,end_time,status,read_count,write_count,anonymized_count,report_path) VALUES (?,?,?,?,?,?,?,?)",
                    jobExecution.getJobInstance().getJobName(),
                    start == null ? null : new java.sql.Timestamp(start.getTime()),
                    end == null ? null : new java.sql.Timestamp(end.getTime()),
                    status,
                    readCount,
                    writeCount,
                    anonymizedCount,
                    filename);
        } catch (Exception e) {
            // ignore DB/report persistence errors
        }
    }
}
