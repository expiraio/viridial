# Anonymisation Test Scenarios

This file describes repeatable test scenarios to validate the RGPD anonymisation job.

Prerequisites
- PostgreSQL dev DB populated from `db/schema.sql` and `db/data.sql`.
- `application-dev.properties` configured with the dev DB credentials.
- Build the project: `mvn -DskipTests package`.

Quick commands
- Build: `mvn -DskipTests package`
- Run (dev profile): `java -jar target/*.jar --spring.profiles.active=dev`

1) Smoke test (dry-run)
- Purpose: confirm selection & count without changing data.
- Steps:
  1. Enable dry-run: set `rgpd.dry-run=true` in `application-dev.properties` or pass `--rgpd.dry-run=true` on the command line.
  2. Run the job:
     ```bash
     java -jar target/*.jar --spring.profiles.active=dev --rgpd.dry-run=true
     ```
  3. Verify results:
     - `SELECT COUNT(*) FROM rgpd_dry_runs;` should be > 0 if candidates exist.
     - `SELECT COUNT(*) FROM beneficiaire WHERE date_anonymization IS NOT NULL;` should be unchanged.

2) Functional run (one chunk)
- Purpose: verify anonymisation logic end-to-end on a small set.
- Steps:
  1. Set `rgpd.dry-run=false`.
  2. Reduce chunk size for quick test: set `rgpd.chunk-size=10` and `rgpd.jdbc-fetch-size=50`.
  3. Run the job and wait for completion.
  4. Checks:
     - `SELECT COUNT(*) FROM beneficiaire WHERE date_anonymization IS NOT NULL;` increased by the number of processed candidates.
     - Spot-check rows: `SELECT id, nir, nom_famille, prenoms, date_anonymization FROM beneficiaire WHERE date_anonymization IS NOT NULL LIMIT 10;`

3) Zero-candidates branch
- Purpose: ensure job reports and behavior when no candidates exist.
- Steps:
  1. Empty `rgpd_candidates` and ensure filters eliminate all: `TRUNCATE rgpd_candidates;` or tweak filters.
  2. Run job.
  3. Expectation: job completes with 0 items processed; report contains candidate count = 0.

4) Edge cases
- Beneficiaire already anonymized: confirm they are excluded from candidate population.
  - Prepare a row with `date_anonymization IS NOT NULL` and check `populateInitialCandidates()` does not include it.
- Recent creation exclusion: create a `beneficiaire` with `date_creation = now()` and confirm exclusion.
- Status exclusions: add `versement`/`regularisation_versement` rows with statuses in exclude list and confirm exclusion.

5) Performance / scaling (million-row simulation)
- Purpose: estimate throughput and tune `chunk-size` and `jdbc-fetch-size`.
- Data prep (use a separate test DB or schema):
  ```sql
  -- create N synthetic beneficiaries quickly (example: 1_000_000)
  INSERT INTO beneficiaire (nir, nom_famille, prenoms, adresse, code_postal, date_creation)
  SELECT 'NIR-' || gs, 'Family' || gs, 'Given' || gs, 'Addr' || gs, '00000', now() - interval '7 years'
  FROM generate_series(1,1000000) gs;
  ```
- Run with tuned settings (example):
  - `rgpd.chunk-size=1000`
  - `rgpd.jdbc-fetch-size=2000`
  - Run the job and measure elapsed time from logs and `rgpd_reports`.

6) Automated assertions (bash)
- Example script skeleton to run dry-run then full-run checks:
  ```bash
  #!/usr/bin/env bash
  set -euo pipefail

  mvn -DskipTests package

  # Dry-run
  java -jar target/*.jar --spring.profiles.active=dev --rgpd.dry-run=true
  dcount=$(psql -h localhost -U rgpduser -d rgpddb -t -c "SELECT COUNT(*) FROM rgpd_dry_runs;")
  echo "dry-run planned updates: $dcount"

  # Full run
  java -jar target/*.jar --spring.profiles.active=dev --rgpd.dry-run=false
  anon_after=$(psql -h localhost -U rgpduser -d rgpddb -t -c "SELECT COUNT(*) FROM beneficiaire WHERE date_anonymization IS NOT NULL;")
  echo "anonymized rows after run: $anon_after"
  ```

7) Verification metrics to assert
- Candidate count > 0 for meaningful runs.
- post_nir_count == pre_nir_count - anonymized_count (if all anonymizations clear nir).
- `rgpd_reports` contains pre/post metrics and a CSV is generated in `reports/`.

Notes and safety
- Always run on a copy of production-like data for tests; do not run destructive tests on production.
- Use `rgpd.dry-run=true` for safe estimation before destructive runs.
- Consider using a dedicated maintenance window for large destructive runs and coordinate DB backups.

If you want, I can:
- Add example SQL fixtures for each edge case.
- Add the bash test script as `scripts/run-tests.sh` in the repo.
